﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'components/Svg/Factory/MarkupFactory',

    'components/Svg/Factory/Template/Shared',
    'components/Svg/Factory/Template/ActiveVisitorBall',
    'components/Svg/Factory/Template/HierarchicalBall',
    'components/Svg/Factory/Template/HighwayBall',
    'components/Svg/Factory/Template/LargeBall',
    'components/Svg/Factory/Template/MediumBall',
    'components/Svg/Factory/Template/TransparentBall',
    'components/Svg/Factory/Template/VisitorBall'
],

function (
// libs
    $,
// live monitor
    utility,

    markupFactory,

    sharedTemplate,
    activeVisitorBallTemplate,
    hierarchicalBallTemplate,
    highwayBallTemplate,
    largeBallTemplate,
    mediumBallTemplate,
    transparentBallTemplate,
    visitorBallTemplate
) {

    // =================================================================================================================================================
    // 'MarkupController' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Svg/Factory/MarkupController'
    // summary:
    //      The controller class for all the markup template
    // description:
    //      Public functions:
    //          init()
    //          load(/*String*/templateKey, /*Boolean?*/includeSvg, /*Array?*/templateLoadArguments, /*Object?*/container)
    //          loadExternal(/*String*/templateKey)
    //          getRegisteredItems()
    //          registerTemplates(/*Array*/templateList)
    //          registerTemplate(/*Object*/template)
    // tags:
    //      public

    var MarkupController = {

        // _filterName: [String] private
        //      The filter function name
        _filterName: 'key',

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        init: function () {
            // summary:
            //      Initialization for the current controller
            // tags:
            //      public

            this._setupDefaultTemplates();
        },

        load: function (/*String*/templateKey, /*Boolean?*/includeSvg, /*Array?*/templateLoadArguments, /*Object?*/container) {
            // summary:
            //      Load the SVG template string by the given template key
            // templateKey: [String]
            //      The given template key that used to translates to the correct template object
            // includeSvg: [Boolean]
            //      Flag indicated that should return the template string included SVG root element or not
            //          TRUE: included
            //          FALSE: not included
            // templateLoadArguments: [Array?]
            //      The given template load arguments
            // container: [Object?]
            //      The given container
            // returns: [String]
            //      A template string in SVG format
            // tags:
            //      public

            var template = this._getRegisteredTemplate(templateKey);
            if (!template) {
                return;
            }

            var markupSettings = template.load.apply(template, templateLoadArguments);

            return markupSettings && markupSettings.svg
                ? markupFactory.create(includeSvg ? markupSettings : markupSettings.svg, container)
                : null;
        },

        loadExternal: function (/*String*/templateKey) {
            // summary:
            //      Load an external SVG file by the given template key
            // templateKey: [String]
            //      The given template key
            // returns: [String]
            //      The external SVG content template string
            // tags:
            //      public

            var template = this._getRegisteredTemplate(templateKey);
            if (!template) {
                return;
            }

            return template.loadExternal();
        },

        // =================================================================================================================================================
        // Register template functions
        // =================================================================================================================================================

        getRegisteredItems: function () {
            // summary:
            //      Get registered templates
            // returns: [Array]
            //      The collection of the registered template object
            // tags:
            //      public

            return this._registeredItems;
        },

        registerTemplates: function (/*Array*/templateList) {
            // summary:
            //      Registers a collection of template object to the current controller
            // templateList: [Array]
            //      The given collection of template object that wants to register to the controller
            // tags:
            //      public

            if (!utility.isValidArray(templateList)) {
                return;
            }

            var totalItems = templateList.length,
                item;

            while (totalItems--) {
                item = templateList[totalItems];
                if (!item) {
                    continue;
                }

                this.registerTemplate(item);
            }
        },

        registerTemplate: function (/*Object*/template) {
            // summary:
            //      Registers the given template to the current controller
            // template: [Object]
            //      The given template object that wants to register to the controller
            // tags:
            //      public

            if (!template || !template.key || !template.name || !$.isFunction(template.load)) {
                return;
            }

            !$.isArray(this._registeredItems) && (this._registeredItems = []);

            if (!utility.getItemFromCollection(this._registeredItems, template, this._filterName)) {
                this._registeredItems.push(template);
            }
        },

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

        _getRegisteredTemplate: function (/*String*/templateKey) {
            // summary:
            //      Get the registered template object by the given template key
            // templateKey: [String]
            //      The given template key
            // returns: [Object]
            //      The registered template object
            // tags:
            //      private

            if (!templateKey) {
                return;
            }

            var filterConditions = {
                key: templateKey
            };

            var template = utility.getItemFromCollection(this._registeredItems, filterConditions, this._filterName);
            if (!template || !$.isFunction(template.load)) {
                return;
            }

            return template;
        },

        _setupDefaultTemplates: function () {
            // summary:
            //      Registers default templates for the controller
            // tags:
            //      private

            this.registerTemplate(sharedTemplate);
            this.registerTemplate(activeVisitorBallTemplate);
            this.registerTemplate(hierarchicalBallTemplate);
            this.registerTemplate(highwayBallTemplate);
            this.registerTemplate(largeBallTemplate);
            this.registerTemplate(mediumBallTemplate);
            this.registerTemplate(transparentBallTemplate);
            this.registerTemplate(visitorBallTemplate);
        }

    };

    // Initialization for the AnimationController
    MarkupController.init();

    return MarkupController;

});