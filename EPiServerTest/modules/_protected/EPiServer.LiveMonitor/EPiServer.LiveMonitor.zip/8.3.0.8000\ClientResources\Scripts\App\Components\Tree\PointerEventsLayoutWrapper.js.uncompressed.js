﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'components/ComponentFactory',

    'components/Svg/ExternalTemplatePreloader',
    'components/Svg/Layout/PointerEventsLayout'
],

function (
// libs
    $,
// live monitor
    utility,

    componentFactory,

    externalTemplatePreloader,
    pointerEventsLayout
) {

    // =================================================================================================================================================
    // 'LiveMonitorPointerEventsLayoutWrapper' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Tree/LiveMonitorPointerEventsLayoutWrapper'
    // summary:
    //      The jQuery plugin for the pointer events (SVG) layout wrapper component
    // description:
    //      use:
    //          $(target).LiveMonitorPointerEventsLayoutWrapper(options);
    //      options:
    //          resources [Object]
    //          baseClasses [String]
    // tags:
    //      public

    // Create the defaults once
    var pluginName = 'LiveMonitorPointerEventsLayoutWrapper',
        pluginOptions = {
            baseClasses: 'livemonitor-layer livemonitor-pointerEventsLayoutWrapper'
        },
        pluginDefinitions = {

            // =================================================================================================================================================
            // Private variables
            // =================================================================================================================================================

            // _svgTemplateKey: [String] private
            //      The key that used to get information about SVG template
            _svgTemplateKey: 'TransparentBall',

            // =================================================================================================================================================
            // Overrided functions
            // =================================================================================================================================================

            _postInit: function () {
                // summary:
                //      Post-initialize settings for the component
                // tags:
                //      protected, extension

                this._setupLayout();
            },

            // =================================================================================================================================================
            // Public callback functions
            // =================================================================================================================================================

            bindData: function (/*Object*/hierarchicalMappingData) {
                // summary:
                //      Binding the given data to the existing highway layout component
                // hierarchicalMappingData: [Object]
                //      The given mapping data object
                // tags:
                //      public, extensions

                $.when(externalTemplatePreloader.getTemplate(this._svgTemplateKey))
                    .done(utility.hitch(this, function (/*String*/templateString) {
                        this._pointerEventsLayout.bindData({
                            hierarchicalMappingData: hierarchicalMappingData,
                            templateString: {
                                transparentBalls: this._getTemplateList(hierarchicalMappingData, templateString)
                            }
                        });
                    }));
            },

            // =================================================================================================================================================
            // Private functions
            // =================================================================================================================================================

            _setupLayout: function () {
                // summary:
                //      Setup layout for the current container
                // tags:
                //      private

                this._pointerEventsLayout = pointerEventsLayout.create({
                    placeHolder: this.element
                });
            },

            _getTemplateList: function (/*Array*/collection, /*String*/templateString) {
                // summary:
                //      Build template collection from the given template string
                // collection: [Array]
                //      The given collection that used to generate template list
                // templateString: [String]
                //      The given template string that used to build the template collection
                // tags:
                //      private

                var totalItems = collection.length,
                    templateList = [];

                while (totalItems--) {
                    templateList.unshift($(templateString)[0]);
                }

                return templateList;
            }
        };

    // A really lightweight plugin $wrapper around the constructor, 
    //  preventing against multiple instantiations
    $.fn[pluginName] = function (/*Object*/options) {
        // summary:
        //      Create a new jQuery plugin from the given settings
        // options: [Object]
        //      The given settings that wanted to decorates the default settings of the current component
        // returns: [Object]
        //      The jQuery plugin object
        // tags:
        //      protected

        // Decorates the default settings by the given settings
        $.extend(true, pluginOptions, options);

        // Create and then return a new jQuery plugin object
        return componentFactory.create(this, pluginName, pluginDefinitions, pluginOptions);
    };

});