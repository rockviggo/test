﻿define([
// libs
    'jquery',
// live monitor
    'utility'
],

function (
// libs
    $,
// live monitor
    utility
) {

    // =================================================================================================================================================
    // 'DefsElementBuilder' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Svg/Factory/Builder/DefsElementBuilder'
    // summary:
    //      The element builder class for 'defs' SVG object
    // description:
    //      Create the 'DEFS' SVG element
    // tags:
    //      public

    var DefsElementBuilder = {

        elementName: 'defs',

        create: function (/*Object*/defsSettings, /*Array*/container, /*Function?*/recursiveCreate) {
            // summary:
            //      Create DEFS svg object from the given settings and then append it to the given container
            // defsSettings: [Object]
            //      The given DEFS settings
            // container: [Array]
            //      The given container
            // recursiveCreate: [Function?]
            //      Indicated that should or should not create children recursively
            // tags:
            //      public

            if (!defsSettings) {
                return;
            }

            var defsList = container.selectAll(this.elementName)
                        .data(utility.getItemCollection(defsSettings))
                            .enter()
                    .append(this.elementName);

            $.isFunction(recursiveCreate) && recursiveCreate(defsSettings, /*container*/defsList);
        }

    };

    return DefsElementBuilder;

});