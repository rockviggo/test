﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'components/ComponentFactory',

    'components/Svg/ExternalTemplatePreloader',
    'components/Svg/Layout/HierarchicalForceLayout',

    'data/HierarchicalMappingRepository'
],

function (
// libs
    $,
// live monitor
    utility,

    componentFactory,

    externalTemplatePreloader,
    hierarchicalForceLayout,

    hierarchicalMappingRepository
) {

    // =================================================================================================================================================
    // Plugin information
    // =================================================================================================================================================
    //
    // module:
    //      Components/Tree/LiveMonitorHierarchicalForceLayoutWrapper
    // summary:
    //      
    // description:
    //      use:
    //          $(target).LiveMonitorHierarchicalForceLayoutWrapper(options);
    //
    //      options:
    //          baseClasses [String]
    //          containerWidth [Integer]
    //          containerHeight [Integer]
    //
    //      required:
    //          
    //          
    // tags:
    //      public

    // Create the defaults once
    var pluginName = 'LiveMonitorHierarchicalForceLayoutWrapper',
        pluginOptions = {
            baseClasses: 'livemonitor-layer livemonitor-hierarchicalForceLayoutWrapper',
            containerWidth: 800,
            containerHeight: 600,
            sender: 'trace',
            // The default callback function is 'getPreloadedContent'
            // Trace callback functions:
            //      getPreloadedContent(contentId, preloadedLevel, languageId)
            //          monitoringTarget: [String]
            //          preloadedLevel: [Integer]
            //          languageId: [String]
            //      getChildContents(parentId, languageId)
            //          parentId: [String]
            //          languageId: [String]
            senderCallback: 'getPreloadedContent'
        },
        pluginDefinitions = {

            // =================================================================================================================================================
            // Private variables
            // =================================================================================================================================================

            // _svgTemplateKey: [String] private
            //      The key that used to get information about SVG template
            _svgTemplateKey: 'HierarchicalBall',

            // =================================================================================================================================================
            // Overrided functions
            // =================================================================================================================================================

            _postInit: function () {
                // summary:
                //      Post-initialize settings for the component
                // tags:
                //      protected, extension

                this._repository = hierarchicalMappingRepository;

                this._setupLayout();
                this._setupEvents();

                this._requestHierarchicalData();
            },

            // =================================================================================================================================================
            // Public callback functions
            // =================================================================================================================================================

            onReceiveCompleted: function (/*Object*/hierarchicalData) {
                // summary:
                //      Fired after client requested to server and then server responsed
                // hierarchicalData: [Object]
                //      The given hierarchical data that will be used to bind to the hierarchical layout control
                // tags:
                //      public, extensions

                hierarchicalData = utility.getJSONObject(hierarchicalData);

                $.when(this._$layoutFinishingDeferred).done(utility.hitch(this, function () {
                    this._$layoutFinishingDeferred = $.Deferred();

                    if (this._hierarchicalData && utility.isEquals(this._hierarchicalData, hierarchicalData)) {
                        return;
                    }

                    // The returned hierarchical data from server side can be:
                    //      Returned from 'getPreloadedContent' function:
                    //          A JSON object that whole information of the tree node (with the root content on top) in hierarchical format
                    //      Returned from 'getChildContents' function:
                    //          An array of JSON object that whole information of the tree node in hierarchical format
                    utility.isValidArray(hierarchicalData)
                        ? this._appendChildrenData(hierarchicalData)
                        : (this._hierarchicalData = hierarchicalData);

                    $.when(externalTemplatePreloader.getTemplate(this._svgTemplateKey))
                        .done(utility.hitch(this, function (/*String*/templateString) {
                            this._repository.injectAncestorsData(this._hierarchicalData);

                            this._hierarchicalForceLayout.bindData({
                                hierarchicalData: this._hierarchicalData,
                                previousMappingData: !this._loadSpecificNodes(this._getSpecificNodeIds()) ? this._repository.getMappingData() : null,
                                templateString: {
                                    hierarchicalBall: templateString
                                }
                            });
                        }));
                }));
            },

            // =================================================================================================================================================
            // Public functions
            // =================================================================================================================================================

            expandContents: function (/*Array*/hierarchicalMappingData, /*Array*/unmappedData) {
                // summary:
                //      Expand the given collection of the content
                // hierarchicalMappingData: [Array]
                //      The given collection of the mapping data for the tree
                // unmappedData: [Array]
                //      The given collection of the un-mapped data for the current instance of the tree
                // tags:
                //      public

                if (!utility.isValidArray(hierarchicalMappingData) || !utility.isValidArray(unmappedData)) {
                    return;
                }

                var totalItems = unmappedData.length,
                    item,
                    ancestors,
                    totalAncestors,
                    ancestor,
                    existingAncestor;

                while (totalItems--) {
                    item = unmappedData[totalItems];
                    if (!item) {
                        continue;
                    }

                    ancestors = item.ancestors;
                    if (!utility.isValidArray(ancestors)) {
                        continue;
                    }

                    totalAncestors = ancestors.length;
                    while (totalAncestors--) {
                        ancestor = ancestors[totalAncestors];
                        if (!ancestor) {
                            continue;
                        }

                        existingAncestor = utility.getItemFromCollection(hierarchicalMappingData, /*filterConditions*/{ contentId: ancestor }, 'contentId');
                        // If a node in the force layout tree already expanded, its 'children' property always null
                        if (existingAncestor && !existingAncestor.expanded && existingAncestor.manualExpanded) {
                            this._requestHierarchicalChildrenData(/*parentContentId*/ancestor);
                        }
                    }
                }
            },

            // =================================================================================================================================================
            // Private events
            // =================================================================================================================================================

            _onHierarchicalLayoutFinishing: function (/*Event*/evt, /*Array*/hierarchicalMappingData, /*Array*/unmappedData) {
                // summary:
                //      Fired when the hierarchical force layout finished it layout process
                // evt: [Event]
                //      The given event
                // hierarchicalMappingData: [Array]
                //      The given mapping data of the hierarchical force layout
                // unmappedData: [Array]
                //      The given un-mapped data of the hierarchical force layout
                // tags:
                //      private

                this._$wrapper.trigger('hierarchicalLayoutFinished', [hierarchicalMappingData, unmappedData]);

                this._$layoutFinishingDeferred && this._$layoutFinishingDeferred.resolve();
            },

            _onRequestChildContents: function (/*Event*/evt, /*Array*/hierarchicalMappingData, /*Object*/parentContent) {
                // summary:
                //      Fired when expanding a tree node that has children
                // evt: [Event]
                //      The given event
                // hierarchicalMappingData: [Array]
                //      The given mapping data of the hierarchical force layout
                // parentContent: [Object]
                //      The given tree node that expanding
                // tags:
                //      private

                this._repository.saveMappingData(hierarchicalMappingData);

                this._requestHierarchicalChildrenData(/*parentContentId*/parentContent.contentId);
            },

            // =================================================================================================================================================
            // Private functions
            // =================================================================================================================================================

            _setupLayout: function () {
                // summary:
                //      Setup layout for the current container
                // tags:
                //      private

                this._hierarchicalForceLayout = hierarchicalForceLayout.create({
                    placeHolder: this.element,
                    layoutSize: {
                        height: this.options.containerHeight,
                        width: this.options.containerWidth
                    }
                });
            },

            _setupEvents: function () {
                // summary:
                //      Setup events for the current container
                // tags:
                //      private

                this._$wrapper.bind('hierarchicalLayoutFinishing', utility.hitch(this, this._onHierarchicalLayoutFinishing));
                this._$wrapper.bind('requestChildContents', utility.hitch(this, this._onRequestChildContents));
            },

            // =================================================================================================================================================
            // Request data functions
            // =================================================================================================================================================

            _requestHierarchicalData: function () {
                // summary:
                //      Send request to server ('getPreloadedContent') in order to get hierarchical data
                // tags:
                //      private

                // Send a request to 'getPreloadedContent' proxy function
                //  with following parameters:
                //      monitoringTarget: [String]
                //          The given root content identification
                //      preloadedLevel: [Integer]
                //          The given preloaded level of the tree
                //      languageId: [String]
                //          The given language identification
                this.options.senderCallback = 'getPreloadedContent';

                var request = {
                    contentId: this._getMonitoringTarget(),
                    preloadedLevel: this._getPreloadedLevel()
                };

                var specificNodeIds = this._getSpecificNodeIds();
                if (this._loadSpecificNodes(specificNodeIds)) {
                    $.extend(true, request, {
                        specificChildContentIdList: specificNodeIds
                    });
                }

                $.isFunction(this.send) && this.send(request);
            },

            _requestHierarchicalChildrenData: function (/*String*/parentContentId) {
                // summary:
                //      Send request to server ('getChildContents') in order to get hierarchical children data
                // parentContentId: [String]
                //      The given parent content id
                // tags:
                //      private

                // Send a request to 'getChildContents' proxy function
                //  with following parameters:
                //      parentContentId: [String]
                //          The given parent content identification
                //      languageId: [String]
                //          The given language identification
                this.options.senderCallback = 'getChildContents';
                $.isFunction(this.send) && this.send({
                    parentId: parentContentId
                });
            },

            _appendChildrenData: function (/*Array*/childrenData) {
                // summary:
                //      Appends the given children data to the current loaded hierarchical data
                // childrenData: [Array]
                //      The given children data that want to appends to the current loaded hierarchical data
                // tags:
                //      private

                if (!utility.isValidArray(childrenData) || !this._hierarchicalData) {
                    return;
                }

                var target = this._getParent(this._hierarchicalData, childrenData[0].parentContentId);
                if (target) {
                    target.children = childrenData;
                }
            },

            _getParent: function (/*Object*/hierarchicalData, /*String*/parentContentId) {
                // summary:
                //      Get parent object of the given children from the given hierarchical data object (hierarchical data)
                // hierarchicalData: [Object]
                //      The hierarhical data
                // parentContentId: [String]
                //      The given parent content id that want to find
                // returns: [Object]
                //      The parent object of the given children
                // tags:
                //      private

                if (hierarchicalData.contentId == parentContentId) {
                    return hierarchicalData;
                }

                var children = hierarchicalData.children;
                if (!hierarchicalData.hasChildren || !utility.isValidArray(children)) {
                    return;
                }

                var totalItems = children.length,
                    parent;

                while (totalItems--) {
                    parent = this._getParent(children[totalItems], parentContentId);
                    if (parent) {
                        return parent;
                    }
                }
            },

            // =================================================================================================================================================
            // Helper functions
            // =================================================================================================================================================

            _loadSpecificNodes: function (/*Array*/specificNodeIds) {
                // summary:
                //      Indicates that the application is in load specific nodes mode or not
                // tags:
                //      private

                return specificNodeIds instanceof Array && specificNodeIds.length > 0;
            },

            _getSpecificNodeIds: function () {
                // summary:
                //      Gets specific node identifications
                // returns: [Array]
                //      An collection of content identification
                // tags:
                //      private

                if (LiveMonitorConfig && typeof LiveMonitorConfig.specificNodeIds === 'string' && LiveMonitorConfig.specificNodeIds.length > 0) {
                    return LiveMonitorConfig.specificNodeIds.split(',');
                }

                return [];
            },

            _getMonitoringTarget: function () {
                // summary:
                //      Get the application monitoring target
                // returns: [String]
                //      The monitoring target content identification
                // tags:
                //      private

                return this._monitoringTarget || (this._monitoringTarget = this.getSetting('monitoringTarget'));
            },

            _getPreloadedLevel: function () {
                // summary:
                //      Get the application hierarchical layout preloaded level number
                // returns: [Integer]
                //      The preloaded level number in the hierarchical layout
                // tags:
                //      private

                return this._preloadedLevel || (this._preloadedLevel = this.getSetting('preloadedLevel'));
            }
        };

    // A really lightweight plugin $wrapper around the constructor, 
    //  preventing against multiple instantiations
    $.fn[pluginName] = function (/*Object*/options) {
        // summary:
        //      Create a new jQuery plugin from the given settings
        // options: [Object]
        //      The given settings that wanted to decorates the default settings of the current component
        // returns: [Object]
        //      The jQuery plugin object
        // tags:
        //      protected

        // Decorates the default settings by the given settings
        $.extend(true, pluginOptions, options);

        // Create and then return a new jQuery plugin object
        return componentFactory.create(this, pluginName, pluginDefinitions, pluginOptions);
    };

});