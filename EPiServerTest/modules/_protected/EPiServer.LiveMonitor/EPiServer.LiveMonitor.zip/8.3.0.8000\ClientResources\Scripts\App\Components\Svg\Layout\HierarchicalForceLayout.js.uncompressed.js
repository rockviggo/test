﻿define([
// libs
    'jquery',
    'd3',
// live monitor
    'utility',

    'components/Svg/Layout/BaseSvgLayout',

    'components/Svg/Factory/MarkupController'
],

function (
// libs
    $,
    dataVisualizer,
// live monitor
    utility,

    baseSvgLayout,

    markupController
) {

    // =================================================================================================================================================
    // Component information
    // =================================================================================================================================================
    //
    // module:
    //      Components/Svg/Layout/HierarchicalForceLayout
    // summary:
    //      Hierarchical force layout
    // description:
    //      
    // tags:
    //      public

    var HierarchicalForceLayout = {

        // Default settings for the given component
        settings: {
            // Default place holder for the current svg element
            placeHolder: 'body',
            layoutSize: {
                // Default height for the force layout
                height: 600,
                // Default width for the force layout
                width: 800
            }
        },

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        create: function (/*Object*/settings) {
            // summary:
            //      Create a new instance of the current component
            // settings: [Object]
            //      The decorated settings for the component
            // returns: [Object]
            //      The hierarchical force layout object
            // tags:
            //      public

            this._layoutFinished = false;

            // Decorates default settings with the new settings
            $.extend(true, this.settings, settings);

            this._$placeHolder = $(this.settings.placeHolder);

            this._createForceLayout();
            this._createSvg();

            this._linkList = this._svg.selectAll('.link');
            this._nodeList = this._svg.selectAll('.hierarchical-content');

            return this;
        },

        bindData: function (/*Object*/hierarhicalForceLayoutData) {
            // summary:
            //      Binding the given hierarchical data to the component
            // hierarchicalForceLayoutData: [Object]
            //      The given hierarchical force layout data object.
            //          hierarchicalData: [Object]
            //              The given hierarchical data
            //          previousMappingData: [Array?]
            //              The given saved previous session hierarchical mapping data
            //          templateString: [String]
            //              The given template string
            // tags:
            //      public

            var hierarchicalData = hierarhicalForceLayoutData.hierarchicalData,
                previousMappingData = hierarhicalForceLayoutData.previousMappingData,
                templateString = hierarhicalForceLayoutData.templateString;

            this._hierarhicalBallTemplateString = templateString.hierarchicalBall;

            this._hierarchicalData = this._root = this._getHierarchicalDataWithRoot(hierarchicalData);
            this._previousMappingData = previousMappingData;

            this._update(/*mapPreviousSessionData*/true);
        },

        // =================================================================================================================================================
        // Private events
        // =================================================================================================================================================

        _onTick: function () {
            // summary:
            //      Set position for nodes and links of the current hierarchical force layout
            //      All positions here will be bounded
            // tags:
            //      private

            utility.isValidArray(this._previousMappingData)
                ? this._setPreviousSessionPositions()
                : this._setNewPositions();

            this._$placeHolder.trigger('hierarchicalLayoutProcessing');
        },

        _onLayoutFinished: function () {
            // summary:
            //      Fired on finished layout process
            // tags:
            //      private

            this._layoutFinished = true;

            this._hierarchicalMappingData = this._getHierarchicalMappingData();
            !this._dragStart && this._$placeHolder.trigger('hierarchicalLayoutFinishing', [this._hierarchicalMappingData, this._unmappedData]);

            this._setFirstLoadState();
        },

        _onForceLayoutDragStart: function (/*Object*/d) {
            // summary:
            //      Fired when the given force layout drag start
            // d: [Object]
            //      The given datum object
            // tags:
            //      private

            var event = dataVisualizer.event;
            if (event && event.defaultPrevented) {
                return;
            }

            this._dragStart = true;
            this._clearSelectedState();

            // Internally, the force layout uses three bits to control whether a node is fixed.
            //  The first bit can be set externally, as in this example.
            //  The second and third bits are set on mouseover and mousedown, respectively, so that nodes are fixed temporarily during dragging.
            //  Although the second and third bits are automatically cleared when dragging ends,
            //  the first bit stays true in this example, and thus nodes remain fixed after dragging.
            d.fixed = true;

            // make drag-node's children go along with
            this._toggleFixedState(d, false);
        },

        _onForceLayoutDragEnd: function (/*Object*/d, /*Object*/sender) {
            // summary:
            //      Fired when the gien force layout drag end
            // d: [Object]
            //      The given datum object
            // sender: [Object]
            //      The given sender object
            // tags:
            //      private

            this._$placeHolder.trigger('hierarchicalContentSelected', [{ contentId: d.contentId }]);
            this._$placeHolder.trigger('hierarchicalLayoutFinishing', [this._hierarchicalMappingData, this._unmappedData]);

            this._dragStart = false;

            // Set SELECTED state for the given element when drag end
            var ring = dataVisualizer.select(sender).select('circle.ring');
            if (ring && ring.node()) {
                this._setSelectedState(ring);
            }

            // make drag-node's children unaffected while dnd
            this._toggleFixedState(d, true);
        },

        _onCollapsible: function (/*Object*/d) {
            // summary:
            //      Toggle children on click.
            // d: [Object]
            //      The given datum object
            // tags:
            //      private

            this._stopPropagation();

            // Ignore drag
            var event = dataVisualizer.event;
            if (event && event.defaultPrevented) {
                return false;
            }

            var requestChildren = d.hasChildren
                && (!d.children || ($.isArray(d.children) && d.children.length === 0))
                && (!d._children || ($.isArray(d._children) && d._children.length === 0));

            if (requestChildren) {
                d.manualExpanded = true;

                this._hierarchicalMappingData = this._getHierarchicalMappingData();
                this._$placeHolder.trigger('requestChildContents', [this._hierarchicalMappingData, { contentId: d.contentId }]);

                return;
            }

            this._toggleChildren(d);
            this._update();
        },

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

        _createForceLayout: function () {
            // summary:
            //      Create the force layout and its children
            // tags:
            //      private

            var layoutSize = this.settings.layoutSize,
                self = this;

            // Create a new force layout
            this._forceLayout = this._forceLayout
                || dataVisualizer.layout.force()
                        .size([layoutSize.width, layoutSize.height])
                        .linkDistance(120)
                        .charge(-120)
                        .gravity(0)
                        .on('tick', utility.hitch(this, this._onTick))
                        .on('end', utility.hitch(this, this._onLayoutFinished));

            this._forceLayoutDrag = this._forceLayoutDrag
                || this._forceLayout.drag()
                        .on('dragstart', utility.hitch(this, this._onForceLayoutDragStart))
                        .on('dragend', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            self._onForceLayoutDragEnd(d, /*sender*/this);
                        });
        },

        _createSvg: function () {
            // summary:
            //      Create the SVG element
            // tags:
            //      private

            // Create a new SVG element and then append it to the given place holder
            this._svg = this._svg || dataVisualizer.select(this.settings.placeHolder).append('svg').attr('class', 'livemonitor-hierarchicalForceLayout');
        },

        _update: function (/*Boolean*/mapPreviousSessionData) {
            // summary:
            //      Update the given hierarchical force layout, includes following actions:
            //          Update existing object(s)
            //          Append new object(s)
            //          Remove old object(s)
            // mapPreviousSessionData: [Boolean]
            //      The given flag indicated that the previous session data should only mapping on the first time of loading the hierarchical component
            // tags:
            //      private

            var nodes = this._flatten(mapPreviousSessionData),
                links = dataVisualizer.layout.tree().links(nodes);

            // Restart the force layout.
            this._forceLayout.nodes(nodes).links(links).start();

            this._updateNodesData(nodes);
            this._updateLinksData(links);
        },

        _getHierarchicalMappingData: function () {
            // summary:
            //      Get hierarchical mapping data
            // returns: [Array]
            //      The collection of the hierarchical content mapping data
            // tags:
            //      private

            var groups = dataVisualizer.selectAll('svg.livemonitor-hierarchicalForceLayout > g')[0],
                totalItems = groups.length,
                hierarchicalMappingData = [],
                group,
                itemData;

            while (totalItems--) {
                group = dataVisualizer.select(groups[totalItems]);
                itemData = group.datum();

                hierarchicalMappingData.push({
                    ancestors: itemData.ancestors,
                    contentId: itemData.contentId,
                    parentContentId: itemData.parentContentId,
                    expanded: utility.isValidArray(itemData.children),
                    manualExpanded: itemData.manualExpanded,
                    x: itemData.x,
                    y: itemData.y
                });
            }

            return hierarchicalMappingData;
        },

        _flatten: function (/*Boolean*/mapPreviousSessionData) {
            // summary:
            //      Returns a list of all nodes under the root.
            // mapPreviousSessionData: [Boolean]
            //      The given flag indicated that the previous session data should only mapping on the first time of loading the hierarchical component
            // tags:
            //      private

            var nodes = [],
                i = 0,
                recurse = function (node) {
                    node.children && node.children.forEach(recurse);
                    !node.contentId && (node.contentId = ++i);

                    nodes.push(node);
                };

            recurse(this._root);

            mapPreviousSessionData && this._mapPreviousSessionData(nodes);

            return nodes;
        },

        _mapPreviousSessionData: function (/*Array*/nodeDataList) {
            // summary:
            //      Mapping previous saved session positions for the current hierarchical nodes
            // nodeDataList: [Array]
            //      The given collection of the node data object
            // tags:
            //      private

            if (!utility.isValidArray(nodeDataList) || !utility.isValidArray(this._previousMappingData)) {
                return;
            }

            this._unmappedData = [];

            var totalItems = this._previousMappingData.length,
                item,
                existing;

            while (totalItems--) {
                item = this._previousMappingData[totalItems];

                existing = utility.getItemFromCollection(nodeDataList, item, 'contentId');
                if (existing) {
                    if (item.manualExpanded != null) {
                        existing.manualExpanded = item.manualExpanded;
                    }

                    existing.expanded = item.expanded;
                    existing.x = item.x;
                    existing.y = item.y;
                } else {
                    this._unmappedData.unshift(item);
                }
            }
        },

        _setNewPositions: function () {
            // summary:
            //      Set new positions for the current hierarchical nodes
            // tags:
            //      private

            this._setNodesPosition(this._nodeList);
            this._setLinksPosition(this._linkList);

            if (this._layoutFinished) {
                this._forceLayout.stop();
            }
        },

        _setPreviousSessionPositions: function () {
            // summary:
            //      Set saved previous session positions for the current hierarchical nodes
            // tags:
            //      private

            this._setNodesPosition(this._nodeList);
            this._setLinksPosition(this._linkList);

            this._forceLayout.stop();
        },

        // =================================================================================================================================================
        // Hierarchical contents functions
        // =================================================================================================================================================

        _updateNodesData: function (/*Array*/nodeDataList) {
            // summary:
            //      Update the node collection from the given data
            // nodeDataList: [Array]
            //      The given collection of node object
            // tags:
            //      private

            // DATA JOIN
            // Join new data with old elements, if any.
            this._nodeList = this._svg.selectAll('.hierarchical-content-container')
                .data(nodeDataList, function (/*Object*/d) {
                    // d: [Object]
                    //      The given datum object

                    return d.contentId;
                });

            // UPDATE
            // Update old elements as needed.
            var updateNodeList = this._nodeList.attr('class', 'hierarchical-content-container updated');
            this._updateNodesLayout(updateNodeList[0]);

            // ENTER
            // Create new elements as needed.
            var newNodeList = this._nodeList.enter().append('g').attr('class', 'hierarchical-content-container enter')
                .call(this._forceLayoutDrag);
            this._setupNodesLayout(newNodeList[0]);

            // Exit any old nodes.
            this._nodeList.exit().remove();
        },

        _setNodesPosition: function (/*Array*/nodeList) {
            // summary:
            //      Set position for the given node collection
            // nodeList: [Array]
            //      The given node collection
            // tags:
            //      private

            nodeList.attr('transform', function (/*Object*/d) {
                // d: [Object]
                //      The given datum object

                return 'translate(' + d.x + ',' + d.y + ')';
            });
        },

        _setupNodesLayout: function (/*Array*/newNodeList) {
            // summary:
            //      Setup layout for the given node list
            // newNodeList: [Array]
            //      The given collection of the new node object
            // tags:
            //      private

            var totalItems = newNodeList.length,
                container,
                containerNode,
                itemData,
                hierarchicalContentContainer,
                ring;

            while (totalItems--) {
                container = dataVisualizer.select(newNodeList[totalItems]);
                containerNode = container.node();

                itemData = containerNode && container.datum();
                if (!itemData) {
                    continue;
                }

                containerNode.appendChild(this._getTemplateContent($(utility.formatTemplateString(this._hierarhicalBallTemplateString, itemData))[0]));

                itemData.isRoot && this._setupRootNode(container);

                this._setupCollapsibleState(container);

                ring = container.select('circle.ring');
                this._setupHoverState(/*senders*/[ring], /*target*/ring);
                this._setupSelectedState(/*senders*/[ring], /*target*/ring);

                ring.on('dblclick', utility.hitch(this, this._onCollapsible));
            }
        },

        _updateNodesLayout: function (/*Array*/updateNodeList) {
            // summary:
            //      Update layout for the given node list
            // updateNodeList: [Array]
            //      The given collection of the updated node object
            // tags:
            //      private

            var totalItems = updateNodeList.length,
                item,
                container;

            while (totalItems--) {
                item = updateNodeList[totalItems];
                container = dataVisualizer.select(item);

                container && this._setupCollapsibleState(container);
            }
        },

        _setupRootNode: function (/*Object*/container) {
            // summary:
            //      Setup root node styles for the current hierarchical component
            // container: [Object]
            //      The given container object
            // tags:
            //      private

            // Mark a hierarchical content if it is root
            var hierarchicalContentContainer = container.select('.hierarchical-content');
            hierarchicalContentContainer && hierarchicalContentContainer.classed('root', true);
        },

        _getHierarchicalDataWithRoot: function (/*Object*/hierarchicalData) {
            // summary:
            //      Set root node and then return the given hierarchical data
            // hierarchicalData: [Object]
            //      The given hierarchical data
            // tags:
            //      private

            hierarchicalData.isRoot = true;

            return hierarchicalData;
        },

        // =================================================================================================================================================
        // Hierarchical links functions
        // =================================================================================================================================================

        _updateLinksData: function (/*Array*/linkDataList) {
            // summary:
            //      Update the link collection from the given data
            // linkDataList: [Array]
            //      The given collection of link object
            // tags:
            //      private

            // Update links.
            this._linkList = this._linkList.data(linkDataList, function (/*Object*/d) {
                // d: [Object]
                //      The given datum object

                return d.target.contentId;
            });

            // Enter any new links.
            this._linkList.enter().insert('line', 'g').attr('class', 'link');

            // Exit any new links.
            this._linkList.exit().remove();
        },

        _setLinksPosition: function (/*Array*/linkList) {
            // summary:
            //      Set position for the given link collection
            // linkList: [Array]
            //      The given link collection
            // tags:
            //      private

            var self = this;
            linkList
                .attr('x1', function (/*Object*/d) {
                    // d: [Object]
                    //      The given datum object

                    return self._getLinkPosition(d.source.x);
                })
                .attr('y1', function (/*Object*/d) {
                    // d: [Object]
                    //      The given datum object

                    return self._getLinkPosition(d.source.y);
                })
                .attr('x2', function (/*Object*/d) {
                    // d: [Object]
                    //      The given datum object

                    return self._getLinkPosition(d.target.x);
                })
                .attr('y2', function (/*Object*/d) {
                    // d: [Object]
                    //      The given datum object

                    return self._getLinkPosition(d.target.y);
                });
        },

        _getLinkPosition: function (/*Integer*/currentPosition) {
            // summary:
            //      Get desired position (to center of a node) from the given position
            // currentPosition: [Integer]
            //      The given current position
            // tags:
            //      private

            // TODO: Remove hard-code settings for radius ('20' value)
            return currentPosition + 20;
        },

        // =================================================================================================================================================
        // Setup states functions
        // =================================================================================================================================================

        _toggleFixedState: function (/*Object*/nodeData, /*Boolean*/fixed) {
            // summary:
            //      Recursive updating the node's fixed state
            // nodeData: [Object]
            //      The given datum of each node
            // fixed: [Boolean]
            //      The fixed value for the state
            // tags:
            //      private

            if (!nodeData.hasChildren) {
                return;
            }

            var recursive = function (node) {
                var children = node.children;
                if (!utility.isValidArray(children)) {
                    return;
                }

                var totalItems = children.length,
                    item;

                while (totalItems--) {
                    item = children[totalItems];

                    // Internally, the force layout uses three bits to control whether a node is fixed.
                    //  The first bit can be set externally, as in this example.
                    //  The second and third bits are set on mouseover and mousedown, respectively, so that nodes are fixed temporarily during dragging.
                    //  Although the second and third bits are automatically cleared when dragging ends,
                    //  the first bit stays true in this example, and thus nodes remain fixed after dragging.
                    item.fixed = fixed;
                    recursive(item);
                }
            };

            recursive(nodeData);
        },

        _setFirstLoadState: function () {
            // summary:
            //      Update the nodes' fixed state after the first load
            // tags:
            //      private

            if (!this._firstLoad) {
                var nodes = this._forceLayout.nodes(),
                    totalItems = nodes.length,
                    item;

                while (totalItems--) {
                    item = nodes[totalItems];
                    // Internally, the force layout uses three bits to control whether a node is fixed.
                    //  The first bit can be set externally, as in this example.
                    //  The second and third bits are set on mouseover and mousedown, respectively, so that nodes are fixed temporarily during dragging.
                    //  Although the second and third bits are automatically cleared when dragging ends,
                    //  the first bit stays true in this example, and thus nodes remain fixed after dragging.
                    item.hasChildren && (item.fixed = true);
                }

                this._firstLoad = true;
            }
        },

        // =================================================================================================================================================
        // HOVER state
        // =================================================================================================================================================

        _setupHoverState: function (/*Array*/senders, /*Object*/target) {
            // summary:
            //      Applies HOVER state for the given node
            // senders: [Array]
            //      The sender node that wanted to send HOVER state event
            // target: [Object]
            //      The given target object that want to applies HOVER state
            // tags:
            //      private

            var totalItems = senders.length,
                sender;
            while (totalItems--) {
                sender = senders[totalItems];

                sender.on('mouseenter', utility.hitch(this, function () {
                    // summary:
                    //      The mouseenter event differs from mouseover in the way it handles event bubbling.
                    //      If mouseover were used in this example, then when the mouse pointer moved over the Inner element, the handler would be triggered.
                    //      This is usually undesirable behavior.
                    //      The mouseenter event, on the other hand, only triggers its handler when the mouse enters the element it is bound to, not a descendant.
                    //      So in this example, the handler is triggered when the mouse enters the Outer element, but not the Inner element.

                    this._stopPropagation();

                    target.classed('hover', true);

                    this._toggleActionLayer(this._$placeHolder, true);
                }));

                sender.on('mouseleave', utility.hitch(this, function () {
                    // summary:
                    //      The mouseleave event differs from mouseout in the way it handles event bubbling.
                    //      If mouseout were used in this example, then when the mouse pointer moved out of the Inner element, the handler would be triggered.
                    //      This is usually undesirable behavior.
                    //      The mouseleave event, on the other hand, only triggers its handler when the mouse leaves the element it is bound to, not a descendant.
                    //      So in this example, the handler is triggered when the mouse leaves the Outer element, but not the Inner element.

                    this._stopPropagation();

                    target.classed('hover', false);

                    this._toggleActionLayer(this._$placeHolder, false);
                }));
            }
        },

        // =================================================================================================================================================
        // SELECTED state
        // =================================================================================================================================================

        _setupSelectedState: function (/*Array*/senders, /*Object*/target) {
            // summary:
            //      Applies SELECTED state for the given node
            // senders: [Array]
            //      The sender node that wanted to send selected state event
            // target: [Object]
            //      The given target object that want to applies selected state
            // tags:
            //      private

            var totalItems = senders.length,
                sender;

            while (totalItems--) {
                sender = senders[totalItems];

                sender.on('click', utility.hitch(this, function (/*Object*/d) {
                    // d: [Object]
                    //      The given datum object

                    this._stopPropagation();

                    var event = dataVisualizer.event;
                    if (event && event.defaultPrevented) {
                        return false;
                    }

                    this._setSelectedState(target);

                    this._$placeHolder.trigger('hierarchicalContentSelected', [{
                        contentId: d.contentId
                    }]);
                }));
            }
        },

        _setSelectedState: function (/*Object*/target) {
            // summary:
            //      Set SELECTED state for the given target element
            // target: [Object]
            //      The given target object that want to applies SELECTED state
            // tags:
            //      private

            this._clearSelectedState();
            target.classed('selected', true);
        },

        _clearSelectedState: function () {
            // summary:
            //      Clear SELECTED state of the given target
            // tags:
            //      private

            this._svg.select('circle.ring.selected').classed('selected', false);
        },

        // =================================================================================================================================================
        // COLLAPSED|EXPANDED state
        // =================================================================================================================================================

        _setupCollapsibleState: function (/*Object*/container) {
            // summary:
            //      Setup EXPANDED|COLLAPSED state for the given container's children
            // container: [Object]
            //      The given container object
            // tags:
            //      private

            var ball = container.select('g.livemonitor-ball'),
                collapsibleController = container.select('text.collapsible-controller');
            this._setCollapsibleState(/*senders*/[collapsibleController], /*target*/ball);
        },

        _setCollapsibleState: function (/*Array*/senders, /*Object*/target) {
            // summary:
            //      Applies EXPANDED|COLLAPSED state for the given node
            // senders: [Array]
            //      The sender node that wanted to send EXPANDED|COLLAPSED state
            // target: [Object]
            //      The given target object that want to applies EXPANDED|COLLAPSED state
            // tags:
            //      private

            var totalItems = senders.length,
                sender;

            while (totalItems--) {
                sender = senders[totalItems];

                sender.text(function (/*Object*/d) {
                    // d: [Object]
                    //      The given datum object

                    d.hasChildren && target.classed('collapsed', !d.children);
                    d.hasChildren && target.classed('expanded', d.children);
                    target.classed('end-point', !d.hasChildren);

                    return d.hasChildren && !d.children ? '+' : '-';
                });

                sender.style('display', function (/*Object*/d) {
                    // d: [Object]
                    //      The given datum object

                    var children = d.children || d._children,
                        display = utility.isValidArray(children);
                    !display && (display = d.hasChildren);

                    return display ? '' : 'none';
                });
            }
        },

        _toggleChildren: function (/*Object*/d) {
            // summary:
            //      Toggle children (show|hide) of the given content
            // d: [Object]
            //      The given datum object
            // tags:
            //      private

            // Toggle children on click.
            if (d.children) {
                // Go to COLLAPSED state
                d.manualExpanded = false;
                d._children = d.children;
                d.children = null;
            } else {
                // Go to EXPANDED state
                d.manualExpanded = true;
                d.children = d._children;
                d._children = null;
            }
        },

        _toggleActionLayer: function (/*Object*/sender, /*Boolean*/enable) {
            // summary:
            //      Toggle the action layer
            // sender: [Object]
            //      The given object that sent message
            // enable: [Boolean]
            //      Enable/Disable the action layer
            // tags:
            //      private

            sender && sender.trigger('toggleActionLayer', [enable]);
        }
    };

    return $.extend(true, {}, baseSvgLayout, HierarchicalForceLayout);

});