﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'app/AppSettings',

    'data/PersistenceCache'
],

function (
// libs
    $,
// live monitor
    utility,

    appSettings,

    persistenceCache
) {

    // =================================================================================================================================================
    // 'TemplateRepository' class information
    // =================================================================================================================================================
    // module:
    //      'App/Data/TemplateRepository'
    // summary:
    //      The repository for application templates
    // description:
    //      Public functions:
    //          getTemplate(/*String*/templateKey)
    //          saveTemplate(/*String*/templateKey, /*String*/template)
    // tags:
    //      public

    var TemplateRepository = {

        // =================================================================================================================================================
        // Private properties
        // =================================================================================================================================================

        // _storageKey: [String] private
        //      The application external templates key
        _storageKey: 'livemonitor-application-templates',

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        getTemplate: function (/*String*/templateKey) {
            // summary:
            //      Get the external template by the give template key
            // templateKey: [String]
            //      The given template key
            // returns: [String]
            //      An external SVG template in the string format
            // tags:
            //      public

            var themeName = this._getThemeName();
            if (!themeName || !templateKey || !this._storage) {
                return;
            }

            var existingData = this._storage.getData(themeName);

            return existingData && existingData.hasOwnProperty(templateKey) && existingData[templateKey];
        },

        saveTemplate: function (/*String*/templateKey, /*String*/template) {
            // summary:
            //      Save the external template to the application storage
            // templateKey: [String]
            //      The given template key
            // template: [String]
            //      The given template string
            // tags:
            //      public

            if (!templateKey || !template || !this._storage) {
                return;
            }

            var themeName = this._getThemeName(),
                data = {};

            data[themeName] = {};
            data[themeName][templateKey] = template;

            this._storage.saveData(data);
        },

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

        _getThemeName: function () {
            // summary:
            //      Get the current application theme name
            // returns: [String]
            //      The current application theme name
            // tags:
            //      private

            return this._themeName = this._themeName || appSettings.getSetting('theme');
        }

    };

    var templateRepository = $.extend(true, {}, persistenceCache, TemplateRepository);
    templateRepository.init();

    return templateRepository;

});