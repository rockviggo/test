﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'components/ComponentFactory',
// resources
    'text!components/Container/Templates/TabContainer.html',
    'text!components/Container/Templates/NavTabsItem.html',
    'text!components/Container/Templates/TabPanesItem.html'
],

function (
// libs
    $,
// live monitor
    utility,

    componentFactory,
// resources
    templateString,
    navTabsItemTemplateString,
    tabPanesItemTemplateString
) {

    // =================================================================================================================================================
    // 'LiveMonitorTabContainer' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Container/LiveMonitorTabContainer'
    // summary:
    //      The jQuery plugin component for the tab container
    // description:
    //      use:
    //          $(target).LiveMonitorTabContainer(options);
    //      options:
    //          resources [Object]
    //          templateString [String]
    //          baseClasses [String]
    //          contentVScrollable [Boolean]
    //          children [Array]
    // tags:
    //      public

    // Create the defaults once
    var pluginName = 'LiveMonitorTabContainer',
        pluginOptions = {
            templateString: templateString,
            baseClasses: 'livemonitor-container',
            contentVScrollable: true,
            children: []
        },
        pluginDefinitions = {

            // _navTabsItemTemplateString: [String] private
            //      Template string for the nav tabs's item
            _navTabsItemTemplateString: navTabsItemTemplateString,

            // _tabPanesItemTemplateString: [String] private
            //      Template string for the tab panes's item
            _tabPanesItemTemplateString: tabPanesItemTemplateString,

            // =================================================================================================================================================
            // Overrided functions
            // =================================================================================================================================================

            layout: function () {
                // summary:
                //      Layout the current component
                // tags:
                //      public, extensions

                this._$tabContentContainer.css('height', (this._$wrapper.height() - this._$navTabsContainer.height()) + 'px');

                this._setChildrenState();
            },

            _postInit: function () {
                // summary:
                //      Post-initialize settings for the component
                // tags:
                //      protected, extension

                this._setupLayout();
            },

            _addChildren: function (/*Array*/children) {
                // summary:
                //      Create new children and then append them to the given container if any
                // children: [Array]
                //      The collection of the object that want to build as the child component of the current component
                // tags:
                //      protected, extensions

                if (!utility.isValidArray(children)) {
                    return;
                }

                this._tabPanesItemList = [];

                var self = this;
                $.each(children, function (index, item) {
                    item && self._appendTab(item);
                });
            },

            // =================================================================================================================================================
            // Private events
            // =================================================================================================================================================

            _onShownBsTab: function (/*Event*/evt) {
                // summary:
                //      Twitter Bootstrap event.
                //      This event fires on tab show after a tab has been shown.
                //      Use event.target and event.relatedTarget to target the active tab and the previous active tab (if available) respectively.
                // evt: [Event]
                //      The given event object
                // tags:
                //      private

                this._setChildrenState();

                this.triggerContextEvent('showVisitorsTabContent');
            },

            // =================================================================================================================================================
            // Private functions
            // =================================================================================================================================================

            _setupLayout: function () {
                // summary:
                //      Initialize default layout settings for the component
                // tags:
                //      private

                this._$navTabsContainer = this._$wrapper.find('.nav.nav-tabs');
                this._$tabContentContainer = this._$wrapper.find('.tab-content');

                this._$tabContentContainer.toggleClass('vertical-scrollable', this.options.contentVScrollable);
            },

            _appendTab: function (/*Object*/tabItemData) {
                // summary:
                //      Create and then append a tab
                // tabItemData: [Object]
                //      The given tab item data object that used to build a tab
                //      Properties:
                //          id: [String]
                //              The given tab identification
                //          name: [String]
                //              The given tab name
                //          content: [String|Object]
                //              The given HTML string or jQuery plugin object
                // tags:
                //      private

                if (!tabItemData) {
                    return;
                }

                this._appendNavTabsItem(tabItemData);
                this._appendTabPanesItem(tabItemData);
            },

            _appendNavTabsItem: function (/*Object*/tabItemData) {
                // summary:
                //      Create and then append a nav tabs's item
                // tabItemData: [Object]
                //      The given tab item data object that used to build a tab
                //      Properties:
                //          id: [String]
                //              The given tab identification
                //          name: [String]
                //              The given tab name
                //          content: [String|Object]
                //              The given HTML string or jQuery plugin object
                // tags:
                //      private

                var $navTabsItem = $(this._navTabsItemTemplateString);
                if (!$navTabsItem) {
                    return;
                }

                $navTabsItem.toggleClass('active', tabItemData.active === true);

                var $anchor = $navTabsItem.find('> a[data-toggle="tab"]');
                if (!$anchor) {
                    return;
                }

                $anchor.on('shown.bs.tab', utility.hitch(this, this._onShownBsTab));

                $anchor.attr('href', '#' + tabItemData.id);
                $anchor.text(tabItemData.name);

                this._$navTabsContainer && this._$navTabsContainer.append($navTabsItem);
            },

            _appendTabPanesItem: function (/*Object*/tabItemData) {
                // summary:
                //      Create and then append a tab panes's item
                // tabItemData: [Object]
                //      The given tab item data object that used to build a tab
                //      Properties:
                //          id: [String]
                //              The given tab identification
                //          name: [String]
                //              The given tab name
                //          content: [String|Object]
                //              The given HTML string or jQuery plugin object
                // tags:
                //      private

                var $tabPanesItem = $(this._tabPanesItemTemplateString);
                if (!$tabPanesItem) {
                    return;
                }

                this._tabPanesItemList.push($tabPanesItem);

                $tabPanesItem.toggleClass('active', tabItemData.active === true);
                $tabPanesItem.attr('id', tabItemData.id);

                (tabItemData && tabItemData.content && tabItemData.content.length > 0)
                    && $tabPanesItem.append(tabItemData.content[0]);

                this._$tabContentContainer && this._$tabContentContainer.append($tabPanesItem);
            },

            _setChildrenState: function () {
                // summary:
                //      Set state for the current component's children
                // tags:
                //      private

                if (!utility.isValidArray(this._tabPanesItemList)) {
                    return;
                }

                var containerState = this.getState(),
                    totalItems = this._tabPanesItemList.length,
                    item,
                    childComponent,
                    childState,
                    instance;

                while (totalItems--) {
                    item = this._tabPanesItemList[totalItems];
                    if (!item) {
                        continue;
                    }

                    childComponent = item.children().first();
                    if (!childComponent) {
                        continue;
                    }

                    instance = utility.getInstance(childComponent);
                    if (!instance || !$.isFunction(instance.setState)) {
                        continue;
                    }

                    childState = containerState !== 'hide' && item.hasClass('active');
                    instance.setState(childState ? 'show' : 'hide');
                }
            }

        };

    // A really lightweight plugin wrapper around the constructor, 
    //  preventing against multiple instantiations
    $.fn[pluginName] = function (/*Object*/options) {
        // summary:
        //      Create a new jQuery plugin from the given settings
        // options: [Object]
        //      The given settings that wanted to decorates the default settings of the current component
        // returns: [Object]
        //      The jQuery plugin object
        // tags:
        //      protected

        // Decorates the default settings by the given settings
        $.extend(true, pluginOptions, options);

        // Create and then return a new jQuery plugin object
        return componentFactory.create(this, pluginName, pluginDefinitions, pluginOptions);
    };

});