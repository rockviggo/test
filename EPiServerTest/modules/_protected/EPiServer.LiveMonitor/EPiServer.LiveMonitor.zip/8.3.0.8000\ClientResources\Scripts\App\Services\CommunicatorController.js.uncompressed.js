﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'app/AppSettings'
],

function (
// libs
    $,
// live monitor
    utility,

    appSettings
) {

    // =================================================================================================================================================
    // 'CommunicatorController' class information
    // =================================================================================================================================================
    // module:
    //      'App/Services/CommunicatorController'
    // summary:
    //      Used to controls all the registered communicator object
    // description:
    //      When register a new communicator object with the controller,
    //      it will automatically register communicator's information (key and name values) with the application settings
    //
    //      Each object that want to register to the communicator controller must have following properties:
    //          key: [String]
    //              The unique value
    //          name: [String]
    //              The friendly name that used to display in the UI
    //
    //      Public functions:
    //          registerCommunicators()
    //              To register the given collection of the new communicator object
    //          registerCommunicator()
    //              To register the given new communicator object
    //          getCommunicator()
    //              To get the registered communicator object by the given communicator's key
    // tags:
    //      public

    // =================================================================================================================================================
    // CommunicatorController class
    // =================================================================================================================================================

    var CommunicatorController = {

        // _filterName: [String] private
        //      The filter function name
        _filterName: 'key',

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        init: function () {
            // summary:
            //      Initialization for the current controller
            // tags:
            //      public

            this._appSettings = appSettings;
        },

        registerCommunicators: function (/*Array*/communicatorList) {
            // summary:
            //      Registers a collection of builder object to the current factory
            // communicatorList: [Array]
            //      The given collection of builder object that wants to register to the factory
            // tags:
            //      public

            if (!utility.isValidArray(communicatorList)) {
                return;
            }

            var totalItems = communicatorList.length;
            while (totalItems--) {
                this.registerCommunicator(communicatorList[totalItems]);
            }
        },

        registerCommunicator: function (/*Object*/communicator) {
            // summary:
            //      Registers the given communicator to the current controller
            // communicator: [Object]
            //      The given communicator object that wants to register to the controller
            // tags:
            //      public

            if (!communicator || !communicator.key) {
                return;
            }

            !$.isArray(this._communicators) && (this._communicators = []);

            if (!utility.getItemFromCollection(this._communicators, communicator, this._filterName)) {
                this._communicators.unshift(communicator);

                // Register communicator name to the application settings
                this._appSettings.registerSetting({
                    settingKey: 'communicator',
                    registerValue: {
                        key: communicator.key,
                        name: communicator.name
                    }
                });
            }
        },

        getCommunicator: function (/*String*/key) {
            // summary:
            //      Get the communicator by the given communicator name
            // key: [String]
            //      The given communicator name
            // tags:
            //      public

            if (!key) {
                return;
            }

            var filterConditions = {
                key: key
            };

            return utility.getItemFromCollection(this._communicators, filterConditions, this._filterName);
        }

    };

    // Initialization for the CommunicatorController
    CommunicatorController.init();

    return CommunicatorController;

});