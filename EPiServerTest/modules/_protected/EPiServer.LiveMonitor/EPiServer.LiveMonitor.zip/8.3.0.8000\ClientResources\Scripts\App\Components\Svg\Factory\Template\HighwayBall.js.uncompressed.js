﻿define([
// libs
    'jquery',
// live monitor
    'components/Svg/Factory/Template/BaseTemplate'
],

function (
// libs
    $,
// live monitor
    baseTemplate
) {

    // =================================================================================================================================================
    // 'HighwayBallTemplate' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Svg/Factory/Template/HighwayBallTemplate'
    // summary:
    //      Provides highway ball content markup template in SVG format
    // description:
    //      Public functions:
    //          load(/*String?*/text)
    //              Load SVG in JSON format
    //          loadExternal()
    //              Load SVG in raw format (SVG markup string)
    // tags:
    //      public

    var HighwayBallTemplate = {

        // key: [String] public
        //      The unique key that used to register to the controller
        //      The controller used this key to identifies each registered template
        key: 'HighwayBall',

        // name: [String] public
        //      The template name that used to register to the controller
        //      The application used this name to display
        name: 'Highway Ball Template',

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        load: function (/*String?*/text) {
            // summary:
            //      Get predefined markup settings for a transfers ball SVG object
            // text: [String?]
            //      The given text that wanted to bind to the 'text' SVG tag
            // returns: [Object]
            //      The JSON markup settings for a transfers ball SVG object
            // tags:
            //      public

            return {
                svg: {
                    height: 30,
                    width: 30,
                    g: {
                        classes: 'livemonitor-ball transfers',
                        circle: {
                            cx: 15,
                            cy: 15,
                            r: 15
                        },
                        text: {
                            classes: 'number',
                            x: 15,
                            y: 20,
                            value: text
                        }
                    }
                }
            };
        }

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

    };

    return $.extend(true, {}, baseTemplate, HighwayBallTemplate);

});