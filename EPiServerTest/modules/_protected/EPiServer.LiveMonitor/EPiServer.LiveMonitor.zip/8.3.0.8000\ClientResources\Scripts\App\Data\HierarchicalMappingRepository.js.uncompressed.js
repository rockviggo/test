﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'app/AppSettings',

    'data/TransferRepository'
],

function (
// libs
    $,
// live monitor
    utility,

    appSettings,

    transferRepository
) {

    // =================================================================================================================================================
    // 'HierarchicalMappingRepository' class information
    // =================================================================================================================================================
    // module:
    //      'App/Data/HierarchicalMappingRepository'
    // summary:
    //      The repository for hierarchical mapping
    // description:
    //      Public functions:
    //          getMappingData()
    //          saveMappingData(/*Array*/hierarchicalMappingData)
    //          injectAncestorsData(/*Object*/hierarchicalData)
    //          sortByAncestorsLevel(/*Object*/object1, /*Object*/object2)
    // tags:
    //      public

    var HierarchicalMappingRepository = {

        // _dataKey: [String] private
        //      The hierarchical mapping data key that used to get/set the hierarchical mapping data
        _dataKey: 'hierarchicalMappingData',

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        getMappingData: function () {
            // summary:
            //      Get the saved hierarchical mapping data from the application storage
            // returns: [Array]
            //      The hierarchical mapping data
            // tags:
            //      public

            var existingData = this.getData(),
                combinedKey = this._getCombinedKey();
            if (!existingData || !combinedKey || !existingData.hasOwnProperty(combinedKey)) {
                return;
            }

            return existingData[combinedKey].mappingData;
        },

        saveMappingData: function (/*Array*/hierarchicalMappingData) {
            // summary:
            //      Save the given hierarchical mapping data to the application storage
            // hierarchicalMappingData: [Array]
            //      The given collection of the hierarchical mapping data object
            // tags:
            //      public

            if (!utility.isValidArray(hierarchicalMappingData)) {
                return;
            }

            $.when(this._getMergedMappingData(hierarchicalMappingData))
                .done(utility.hitch(this, function (mergedMappingData) {
                    var data = {},
                        combidedKey = this._getCombinedKey();
                    data[combidedKey] = {
                        mappingData: mergedMappingData
                    };

                    this.saveData(data, {
                        replace: true,
                        fieldKey: combidedKey
                    });
                }));
        },

        injectAncestorsData: function (/*Object*/hierarchicalData) {
            // summary:
            //      Inject ancestors data to the given hierarchical data
            // hierarchicalData: [Object]
            //      The given hierarchical data
            // tags:
            //      public

            var recursive = function (parent, existingAncestors) {
                if (!parent || !utility.isValidArray(existingAncestors)) {
                    return;
                }

                var children = parent.children;
                if (!utility.isValidArray(children)) {
                    return;
                }

                var totalItems = children.length,
                    item;

                while (totalItems--) {
                    item = children[totalItems];
                    if (!item) {
                        continue;
                    }

                    item.ancestors = existingAncestors.slice(0);

                    recursive(item, $.inArray(item.contentId, item.ancestors) === -1 && [item.contentId].concat(item.ancestors));
                }
            };

            recursive(hierarchicalData, [hierarchicalData.contentId]);
        },

        sortByAncestorsLevel: function (/*Object*/object1, /*Object*/object2) {
            // summary:
            //      Sort by ancestors level
            // object1: [Object]
            //      The given object 1 that used to comparing and then sorting
            // object2: [Object]
            //      The given object 2 that used to comparing and then sorting
            // returns: [Integer]
            //      
            // tags:
            //      public

            var sortProperty = 'ancestors';

            if (!object1 || !object2) {
                return 0;
            }

            if (!object1.hasOwnProperty(sortProperty) || !object2.hasOwnProperty(sortProperty)) {
                return 0;
            }

            if (!$.isArray(object1[sortProperty]) || !$.isArray(object2[sortProperty])) {
                return 0;
            }

            if (object1[sortProperty].length < object2[sortProperty].length) {
                return -1;
            }

            if (object1[sortProperty].length > object2[sortProperty].length) {
                return 1;
            }

            return 0;
        },

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

        _getCombinedKey: function () {
            // summary:
            //      Build a combined key for saving hierarchical mapping data based on following:
            //          languageId [String]
            // returns: [String]
            //      The combined key string
            // tags:
            //      private

            return this._combinedKey = this._combinedKey
                || utility.getCombinedKey([appSettings.getSetting('languageId')], /*separator*/'_');
        },

        // =================================================================================================================================================
        // Process hierarchical mapping data functions
        // =================================================================================================================================================

        _sortByContentId: function (/*Object*/object1, /*Object*/object2) {
            // summary:
            //      Sort by 'contentId' property
            // object1: [Object]
            //      The given object 1 that used to comparing and then sorting
            // object2: [Object]
            //      The given object 2 that used to comparing and then sorting
            // returns: [Integer]
            //      
            // tags:
            //      public

            var sortProperty = 'contentId';

            if (!object1 || !object2) {
                return 0;
            }

            if (!object1.hasOwnProperty(sortProperty) || !object2.hasOwnProperty(sortProperty)) {
                return 0;
            }

            if (object1[sortProperty] < object2[sortProperty]) {
                return -1;
            }

            if (object1[sortProperty] > object2[sortProperty]) {
                return 1;
            }

            return 0;
        },

        _getMergedMappingData: function (/*Array*/hierarchicalMappingData) {
            // summary:
            //      Merget the given hierarchical mapping data with the saved data in the application settings
            // hierarchicalMappingData: [Array]
            //      The given collection of the hierarchical mapping data object
            // returns: [Array]
            //      The merged hierarchical mapping data
            // tags:
            //      private

            var $deferred = $.Deferred(),
                existingData = this.getMappingData();
            if (!utility.isValidArray(existingData)) {
                return hierarchicalMappingData;
            }

            var totalItems = existingData.length,
                item,
                existingItem,
                mergedData = utility.cloneObject(hierarchicalMappingData);

            while (totalItems--) {
                item = existingData[totalItems];
                if (!item) {
                    continue;
                }

                existingItem = utility.getItemFromCollection(hierarchicalMappingData, item, 'contentId');
                if (!existingItem) {
                    mergedData.push(item);
                }

                if (totalItems === 0) {
                    $deferred.resolve(mergedData);
                }
            }

            return $deferred;
        }

    };

    var hierarchicalMappingRepository = $.extend(true, {}, transferRepository, HierarchicalMappingRepository);
    hierarchicalMappingRepository.init();

    return hierarchicalMappingRepository;

});