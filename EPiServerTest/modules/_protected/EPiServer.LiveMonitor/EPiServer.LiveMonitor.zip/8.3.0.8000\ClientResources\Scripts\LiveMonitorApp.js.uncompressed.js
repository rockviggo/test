﻿requirejs && requirejs.config({
    paths: {
        text: 'Libs/require/text',

        jquery: 'Libs/jquery/jquery',
        jqueryValidate: 'Libs/jquery/jquery.validate',

        bootstrap: 'Libs/bootstrap/js/bootstrap',

        d3: 'Libs/d3/d3',

        signalR: 'Libs/signalR/jquery.signalR',

        fake: 'Fake',

        app: 'App',
        utility: 'App/AppUtility',
        components: 'App/Components',
        data: 'App/Data',
        services: 'App/Services'
    },
    shim: {
        jquery: {
            exports: '$'
        },
        bootstrap: {
            deps: ['jquery']
        },
        signalR: {
            deps: ['jquery']
        },
        'signalR.hubs': {
            deps: ['signalR']
        },
        d3: {
            exports: 'd3'
        }
    }
});

requirejs && requirejs.config({
    baseUrl: LiveMonitorConfig.clientResourcesRootPath + '/Scripts',
    paths: {
        'signalR.hubs': LiveMonitorConfig.signalRHubs
    }
});

// Load the main app module to start the app
requirejs(['app/AppMain']);