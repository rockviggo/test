﻿define([
// libs
    'jquery'
],

function (
// libs
    $
) {

    // =================================================================================================================================================
    // 'HeartBeatAnimation' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Svg/Animation/Effect/HeartBeatAnimation'
    // summary:
    //      The heart beat effect
    // description:
    //      This is an animation to creating heart beat effect for a visitor in Dashboard
    //      Public functions:
    //          apply(/*Object*/marker, /*Integer*/delay)
    // tags:
    //      public

    var HeartBeatAnimation = {

        // =================================================================================================================================================
        // Private properties
        // =================================================================================================================================================

        _initRadius: 0,
        _beatPower: 1.25,

        // =================================================================================================================================================
        // Public properties
        // =================================================================================================================================================

        // key: [String] public
        //      The unique key that used to register to the controller
        //      The controller used this key to identifies each registered animation animation
        key: 'HeartBeat',

        // name: [String] public
        //      The animation animation name that used to register to the controller
        //      The application used this name to display
        name: 'Heart Beat',

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        apply: function (/*Object*/marker, /*Integer*/delay) {
            // summary:
            //      Create an animation pattern
            // marker: [Object]
            //      The given object that wanted to bind the indicated animation
            // delay: [Integer]
            //      The given delay time
            // tags:
            //      public

            // animateGrowingCircle is given a starting radius and an ending radius, and creates a transition function that cycles between those radii and loop
            var circle = marker.select('circle.ring');
            if (circle && (!circle.node() || $(circle.node()).css('display') === 'none')) {
                circle = marker.select('circle.icon');
            } else {
                circle = marker.select('circle');
            }

            if (!circle || !circle.node()) {
                return;
            }

            // Get the initial radius directly from the SVG
            if (!this._initRadius) {
                this._initRadius = circle.attr('r');
            }

            var fromRadius = this._initRadius,
                toRadius = fromRadius * this._beatPower;

            // this animation on r is perf-better than do attr('transform', 'scale(0.8)');
            var repeat = function () {
                circle.attr('r', fromRadius)
                        .transition().duration(400)
                        .attr('r', toRadius)
                        .delay(2000)
                        .transition().duration(1000)
                        .attr('r', fromRadius)
                        .each('end', repeat);
            };

            setTimeout(repeat, delay);
        },

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

    };

    return HeartBeatAnimation;

});