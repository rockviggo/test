﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'data/AppStorage'
],

function (
// libs
    $,
// live monitor
    utility,

    appStorage
) {

    // =================================================================================================================================================
    // 'PersistenceCache' class information
    // =================================================================================================================================================
    // module:
    //      'App/Data/PersistenceCache'
    // summary:
    //      The base class for application persistence storage
    // description:
    //      Public functions:
    //          init()
    //          resetToDefault()
    // tags:
    //      public

    var PersistenceCache = {

        // _storageKey: [String] private
        //      The storage key that used to identifies an application storage
        _storageKey: '',

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        init: function () {
            // summary:
            //      Initialization settings
            // tags:
            //      public

            if (!this._storageKey) {
                return;
            }

            this._storage = appStorage.getInstance(this._storageKey);

            this._onInit();
        },

        resetToDefault: function () {
            // summary:
            //      Restore to the pre-defined settings values
            // tags:
            //      public

            this._storage.clear();

            this._onResetToDefault();
        },

        // =================================================================================================================================================
        // Protected functions
        // =================================================================================================================================================

        _onInit: function () {
            // summary:
            //      Stub to add custom processes when initializing the persistence cache
            // tags:
            //      protected, extension
        },

        _onResetToDefault: function () {
            // summary:
            //      Stub to add custom processes when reseting the persistence cache
            // tags:
            //      protected, extension
        }

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

        

    };

    return PersistenceCache;

});