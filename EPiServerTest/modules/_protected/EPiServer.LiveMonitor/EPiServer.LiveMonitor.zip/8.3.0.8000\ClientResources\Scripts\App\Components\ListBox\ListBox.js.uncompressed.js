﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'components/ComponentFactory',

    'components/ListBox/AppSettingsListBoxItem',
    'components/ListBox/HistoryVisitorsListBoxItem',
    'components/ListBox/ListBoxItem',
    'components/ListBox/OnlineVisitorsListBoxItem',
// resources
    'text!components/ListBox/Templates/ListBox.html'
],

function (
// libs
    $,
// live monitor
    utility,

    componentFactory,

    appSettingsListBoxItem,
    historyVisitorsListBoxItem,
    listBoxItem,
    onlineVisitorsListBoxItem,
// resources
    templateString
) {

    // =================================================================================================================================================
    // 'LiveMonitorListBox' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/ListBox/LiveMonitorListBox'
    // summary:
    //      The jQuery plugin component for the listbox
    // description:
    //      use:
    //          $(target).LiveMonitorListBox(options);
    //      options:
    //          resources [Object]
    //          templateString [String]
    //          baseClasses [String]
    //          itemPlugin [String]
    //          itemIdPrefix [String]
    //          itemIdField [String]
    //          showHeading [Boolean]
    // tags:
    //      public

    // Create the defaults once
    var pluginName = 'LiveMonitorListBox',
        pluginOptions = {
            templateString: templateString,
            baseClasses: 'livemonitor-listBox',
            itemPlugin: 'LiveMonitorListBoxItem',
            showHeading: false
        },
        pluginDefinitions = {

            // =================================================================================================================================================
            // Overrided functions
            // =================================================================================================================================================

            _postInit: function () {
                // summary:
                //      Post-initialize settings for the component
                // tags:
                //      protected, extension

                this._setupLayout();
                this._setupEvents();
            },

            // =================================================================================================================================================
            // Public functions
            // =================================================================================================================================================

            getChildren: function () {
                // summary:
                //      Get registered children of the current component
                // returns: [Array]
                //      The collection of the instance of the 'ListBoxItem' class
                // tags:
                //      public

                return this._children;
            },

            bindData: function (/*Object*/data) {
                // summary:
                //      Executes binding the given data to the current component and|or its children
                // data: [Object]
                //      The given data used to binding
                // tags:
                //      public, extensions

                if (this.getState() === 'hide') {
                    return;
                }

                var $listContainer = this._$wrapper.find('.item-list');
                if (!$listContainer || !$.isArray(data)) {
                    return;
                }

                this._children = [];
                $listContainer.empty();

                var totalItems = data.length;
                if (totalItems === 0) {
                    return;
                }

                var fragment = document.createDocumentFragment(),
                    itemData;
                for (var i = 0; i < totalItems; i++) {
                    itemData = data[i];
                    if (itemData) {
                        this._addChild(itemData, fragment);
                    }
                }
                $listContainer.append(fragment);

                this._setupSelection();
            },

            // =================================================================================================================================================
            // Private functions
            // =================================================================================================================================================

            _setupLayout: function () {
                // summary:
                //      Setup layout for the current component
                // tags:
                //      private

                this._$heading = this._$wrapper.find('.heading');

                this._resources.groupname && this.options.showHeading && this._$heading.html(this._resources.groupname);
            },

            _setupEvents: function () {
                // summary:
                //      Setup events for the current component
                // tags:
                //      private

                // Toggle SELECTED state on its children
                this._$wrapper.bind('childSelected', utility.hitch(this, function (/*Event*/evt, /*Object*/sender) {
                    this._toggleSelectedState(sender);
                }));
            },

            _setupSelection: function () {
                // summary:
                //      Setup selection for the current component and its children
                // tags:
                //      private

                var previousSelectionData = this.getContextSelection();
                if (!previousSelectionData || !previousSelectionData.onlineVisitorId) {
                    return;
                }

                var targetSelector = '#' + previousSelectionData.onlineVisitorId,
                    target = utility.getInstance(targetSelector);
                target && this._toggleSelectedState(target);
            },

            _toggleSelectedState: function (/*Object*/target) {
                // summary:
                //      Toggle selection state for the current component and its children
                // target: [Object]
                //      The given target that wanted to set selected state
                // tags:
                //      private

                var children = this._children;
                if (!utility.isValidArray(children)) {
                    return;
                }

                var totalItems = children.length,
                    item;
                for (var i = 0; i < totalItems; i++) {
                    item = children[i];
                    if (item && $.isFunction(item.toggleSelectedState)) {
                        item.toggleSelectedState(false);
                    }
                }

                (target && $.isFunction(target.toggleSelectedState)) && target.toggleSelectedState(true);
            },

            _addChild: function (/*Object*/itemData, /*Object*/container) {
                // summary:
                //      Create a new child component and then append it to the given container
                // itemData: [Object]
                //      The given object information
                // container: [Object]
                //      The given container object
                // tags:
                //      private

                var itemPlugin = this.options.itemPlugin;
                if (!$.isFunction($()[itemPlugin])) {
                    return;
                }

                var listItem = $('<div></div>')[itemPlugin]({
                    resources: this._resources,
                    extraInfoResources: this.options.extraInfoResources,
                    itemData: itemData
                });

                this._children.push(utility.getInstance(listItem));

                listItem.appendTo(container).wrap('<li></li>');
            }
        };

    // A really lightweight plugin wrapper around the constructor, 
    //  preventing against multiple instantiations
    $.fn[pluginName] = function (/*Object*/options) {
        // summary:
        //      Create a new jQuery plugin from the given settings
        // options: [Object]
        //      The given settings that wanted to decorates the default settings of the current component
        // returns: [Object]
        //      The jQuery plugin object
        // tags:
        //      protected

        // Decorates the default settings by the given settings
        $.extend(true, pluginOptions, options);

        // Create and then return a new jQuery plugin object
        return componentFactory.create(this, pluginName, pluginDefinitions, pluginOptions);
    };

});