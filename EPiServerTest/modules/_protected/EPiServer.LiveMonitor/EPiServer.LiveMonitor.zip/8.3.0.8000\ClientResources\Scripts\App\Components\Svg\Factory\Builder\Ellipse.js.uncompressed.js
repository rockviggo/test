﻿define([
// libs
    'jquery',
// live monitor
    'utility'
],

function (
// libs
    $,
// live monitor
    utility
) {

    // =================================================================================================================================================
    // 'EllipseElementBuilder' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Svg/Factory/Builder/EllipseElementBuilder'
    // summary:
    //      The element builder class for 'ellipse' SVG object
    // description:
    //      Create the 'ELLIPSE' SVG element
    // tags:
    //      public

    var EllipseElementBuilder = {

        elementName: 'ellipse',

        create: function (/*Object*/ellipseSettings, /*Array*/container, /*Function?*/recursiveCreate) {
            // summary:
            //      Create and then append a SVG ellipse without '<svg></svg>' tag
            // ellipseSettings: [Object]
            //      The given ELLIPSE settings
            // container: [Array]
            //      The given container
            // recursiveCreate: [Function?]
            //      Indicated that should or should not create children recursively
            // tags:
            //      public

            if (!ellipseSettings) {
                return;
            }

            var ellipseList = container.selectAll(this.elementName)
                        .data(utility.getItemCollection(ellipseSettings))
                            .enter()
                    .append(this.elementName)
                        .attr('class', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.classes;
                        })
                        .attr('cx', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.cx;
                        })
                        .attr('cy', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.cy;
                        })
                        .attr('rx', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.rx;
                        })
                        .attr('ry', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.ry;
                        })
                        .attr('fill', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.fill;
                        });

            $.isFunction(recursiveCreate) && recursiveCreate(ellipseSettings, /*container*/ellipseList);
        }

    };

    return EllipseElementBuilder;

});