﻿define([
// libs
    'jquery',
// live monitor
    'utility'
],

function (
// libs
    $,
// live monitor
    utility
) {

    // =================================================================================================================================================
    // 'AppStorage' class information
    // =================================================================================================================================================
    // module:
    //      'App/Data/AppStorage'
    // summary:
    //      The application storage class
    // description:
    //      Public functions:
    //          getInstance(/*String*/storageKey)
    //          getAllData()
    //          getData(/*String*/dataKey)
    //          saveData(/*Object*/data, /*Object?*/options)
    //          clear(/*String*/dataKey)
    // tags:
    //      public

    var AppStorage = {

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        getInstance: function (/*String*/storageKey) {
            // summary:
            //      Get an instance of the storage by the given storage key
            // storageKey: [String]
            //      The given storage key
            // returns: [Object]
            //      An instance of the storage object
            //      That have following public methods:
            //          getAllData() [Function]
            //              Get entire saved data in the application storage
            //          getData() [Function]
            //              Get saved value by key in the application storage
            //          saveData() [Function]
            //              Save the given data to the application storage
            //          clear() [Function]
            //              Clear existing data in the application storage
            // tags:
            //      public

            return {
                getAllData: utility.hitch(this, function () {
                    return this._getExistingData(storageKey);
                }),
                getData: utility.hitch(this, function (/*String*/dataKey) {
                    return this._getFromStorage(storageKey, dataKey);
                }),
                saveData: utility.hitch(this, function (/*Object*/data, /*Object?*/options) {
                    this._saveToStorage(storageKey, data, options);
                }),
                clear: utility.hitch(this, function (/*String*/dataKey) {
                    this._clearExistingData(storageKey, dataKey);
                })
            };
        },

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

        _getFromStorage: function (/*String*/storageKey, /*String*/key) {
            // summary:
            //      Get value from store by the given key
            // storageKey: [String]
            //      The given storage key that used to identifies the storage
            // key: [String]
            //      The given key
            // returns: [Object]
            //      The value that got from the store by the given key
            // tags:
            //      private

            if (!this._storageReady() || !key) {
                return;
            }

            var existingData = this._getExistingData(storageKey);
            if (!existingData) {
                return;
            }

            return existingData.hasOwnProperty(key) && existingData[key];
        },

        _saveToStorage: function (/*String*/storageKey, /*Object*/data, /*Object?*/options) {
            // summary:
            //      Save the given data object to the store
            // storageKey: [String]
            //      The given storage key that used to identifies the storage
            // data: [Object]
            //      The given data object
            // options: [Object?]
            //      Object's properties:
            //          replace: [Boolean]
            //              The flag that indicates should or should not replace the existing data
            //          dataKey: [String]
            //              The key of the data object
            //          fieldKey: [String]
            //              The key of the data object's field
            // replace: [Boolean?]
            //      The given flag to indicate that should or should not replace existing data
            // tags:
            //      private

            if (!this._storageReady() || !data) {
                return;
            }

            var existingData = this._getExistingData(storageKey),
                updatedData = data;

            if (existingData) {
                var replace = options && options.replace,
                    dataKey = options && options.dataKey,
                    fieldKey = options && options.fieldKey,
                    validToReplace = replace
                        && $.type(dataKey) === 'string' && $.type(fieldKey) === 'string'
                        && options.hasOwnProperty(dataKey) && options.hasOwnProperty(fieldKey);

                // jQuery.extend() function had issue if the given data is an instance of Array or its property is an instance of Array.
                // So that, use another way to merge/replace existing data.
                if (validToReplace) {
                    existingData[dataKey][fieldKey] = data[dataKey][fieldKey];
                    updatedData = existingData;
                } else {
                    updatedData = $.extend(true, {}, existingData, data);
                }
            }

            localStorage.setItem(storageKey, JSON.stringify(updatedData));
        },

        _getExistingData: function (/*String*/storageKey) {
            // summary:
            //      Get the existing data of the current application
            // storageKey: [String]
            //      The given storage key that used to identifies the storage
            // returns: [Object]
            //     The saved data of the application
            // tags:
            //      private

            if (!this._storageReady() || !storageKey) {
                return;
            }

            var existingData;
            try {
                existingData = JSON.parse(localStorage.getItem(storageKey));
            } catch (e) {
                existingData = {};
            }

            return existingData;
        },

        _clearExistingData: function (/*String*/storageKey, /*String*/fieldKey) {
            // summary:
            //      Clear the existing data from the storage that have the given key
            // storageKey: [String]
            //      The given storage key that used to identifies the storage
            // fieldKey: [String]
            //      The given data key that used to identifies the data in the storage
            // tags:
            //      private

            if (!this._storageReady() || !storageKey) {
                return;
            }

            if (fieldKey) {
                var existingData = this._getExistingData(storageKey);
                if (existingData && existingData.hasOwnProperty(fieldKey)) {
                    existingData[fieldKey] = {};
                }
            } else {
                existingData = {};
            }

            localStorage.setItem(storageKey, JSON.stringify(existingData));
        },

        _storageReady: function () {
            // summary:
            //      Check for HTML5 storage is ready or not
            // returns: [Boolean]
            //      TRUE for supported
            //      FALSE for not supported
            // tags:
            //      private

            try {
                return 'localStorage' in window && window['localStorage'] !== null;
            } catch (e) {
                return false;
            }
        }

    };

    return AppStorage;

});