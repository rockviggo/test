﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'components/Svg/Factory/MarkupController',

    'data/TemplateRepository'
],

function (
// libs
    $,
// live monitor
    utility,

    markupController,

    templateRepository
) {

    // =================================================================================================================================================
    // 'ExternalTemplateLoader' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Svg/ExternalTemplatePreloader'
    // summary:
    //      The external template preloader for application
    // description:
    //      Public functions:
    //          init()
    //          appendShared(/*Object*/container)
    //          loadTemplates()
    //          getTemplate(/*String*/templateKey)
    // tags:
    //      public

    var ExternalTemplatePreloader = {

        // =================================================================================================================================================
        // Private properties
        // =================================================================================================================================================

        _sharedTemplateKey: 'Shared',

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        init: function () {
            // summary:
            //      Initialization for the current controller
            // tags:
            //      public

            this._repository = templateRepository;
        },

        appendShared: function (/*Object*/container) {
            // summary:
            //      Append the shared (common settings for all the registered SVG templates) to the given container object
            // container: [Object]
            //      The given container object that used to append the shared for all the registered SVG templates
            // tags:
            //      public

            // Append SVG shared settings
            $.when(this.getTemplate(/*templateKey*/this._sharedTemplateKey))
                .done(utility.hitch(this, function (/*Object*/sharedTemplateString) {
                    container.prepend(sharedTemplateString);
                }));
        },

        loadTemplates: function () {
            // summary:
            //      Load all the registered external SVG templates
            // tags:
            //      public

            var registeredTemplates = markupController.getRegisteredItems();
            if (!utility.isValidArray(registeredTemplates)) {
                return;
            }

            var totalItems = registeredTemplates.length,
                item,
                templateDeferredList = [];

            while (totalItems--) {
                item = registeredTemplates[totalItems];
                if (!item || !item.key) {
                    continue;
                }

                templateDeferredList.unshift(this.getTemplate(item.key));
            }

            $.when.apply($, templateDeferredList).done(utility.hitch(this, this._loadTemplates));
        },

        getTemplate: function (/*String*/templateKey) {
            // summary:
            //      Get the external SVG template by the give template key
            // templateKey: [String]
            //      The given template key
            // returns: [String]
            //      An external SVG template in the string format
            // tags:
            //      public

            if (!templateKey) {
                return;
            }

            return this._repository.getTemplate(templateKey)
                || $.when(markupController.loadExternal(templateKey))
                        .done(utility.hitch(this, function (/*Object*/templateString) {
                            templateString = utility.getOuterContent(templateString);
                            if (!templateString) {
                                return;
                            }

                            this._repository.saveTemplate(templateKey, templateString);

                            return templateString;
                        }));
        },

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

        _loadTemplates: function () {
            // summary:
            //      Load all the template string (with SVG root element) to the application storage
            // tags:
            //      private

            var registeredTemplates = markupController.getRegisteredItems(),
                totalItems = registeredTemplates.length,
                templateKey,
                template;

            while (totalItems--) {
                templateKey = registeredTemplates[totalItems].key;
                template = utility.getOuterContent(arguments[totalItems]);

                this._repository.saveTemplate(/*templateKey*/templateKey, /*template*/template);
            }
        }

    };

    ExternalTemplatePreloader.init();

    return ExternalTemplatePreloader;

});