﻿/*!
 * jQuery lightweight component boilerplate
 * Original author: @ajpiano
 * Further changes, comments: @addyosmani
 * Licensed under the MIT license
 */

var HierarchicalLayout;

// the semi-colon before the function invocation is a safety 
// net against concatenated scripts and/or other components 
// that are not closed properly.
; (function ($, window, document, dataVisualizer, svgObjectFactory, svgPredefined, undefined) {

    // undefined is used here as the undefined global 
    // variable in ECMAScript 3 and is mutable (i.e. it can 
    // be changed by someone else). undefined isn't really 
    // being passed in so we can ensure that its value is 
    // truly undefined. In ES5, undefined can no longer be 
    // modified.

    // window and document are passed through as local 
    // variables rather than as globals, because this (slightly) 
    // quickens the resolution process and can be more 
    // efficiently minified (especially when both are 
    // regularly referenced in your component).

    HierarchicalLayout = {
        // Default settings for the component
        settings: {
            placeHolder: 'body',
            layoutSize: {
                height: 600,
                width: 800
            }
        },

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        create: function (settings) {
            // summary:
            //      Create an instance of the component
            // settings: [Object]
            //      The given layout settings
            // returns: [Object]
            //      The instance of the component
            // tags:
            //      public

            $.extend(true, this.settings, settings);

            var layoutSize = this.settings.layoutSize;

            // Create a new SVG element and then append it to the given place holder
            this._svg = dataVisualizer.select(this.settings.placeHolder).append('svg');

            // Create a new hierarchical layout (tree layout) with the given size (width, height)
            this._hierarchicalLayout = dataVisualizer.layout.tree()
                .size([layoutSize.width, layoutSize.height]);

            return this;
        },

        bindData: function (hierarchicalData) {
            // summary:
            //      Bind the given hierarchical data to the component
            // hierarchicalData: [Object]
            //      The given hierarchical data
            // tags:
            //      public

            if (this._dataCache) {
                return;
            }

            this._dataCache = this._root = hierarchicalData;
            this._update();
        },

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

        // =================================================================================================================================================
        // Hierarchical functions
        // =================================================================================================================================================

        _update: function () {
            // summary:
            //      
            // tags:
            //      private

            var layoutSize = this.settings.layoutSize,
                centerX = layoutSize.width / 2,
                centerY = layoutSize.height / 2;

            // Compute the new hierarchical layout
            var nodes = this._hierarchicalLayout.nodes(this._root).reverse(),
                links = this._hierarchicalLayout.links(nodes);

            // Normalize or fixed-depth
            nodes.forEach(function (d) {
                d.x += 20;
                d.y += 20;
            });

            // Update the nodes
            var node = this._svg.selectAll('.tree-node-container')
                .data(nodes, function (d) {
                    return d.id;
                });

            // Enter any new nodes at the parent's previous position
            var nodeEnter = node.enter()
                .append('g')
                .attr('class', 'tree-node-container')
                .attr('transform', function (d) {
                    return 'translate(' + d.y + ',' + d.x + ')';
                });

            var self = this,
                svgGroup;

            $.each(nodeEnter[0], function (index, item) {
                svgGroup = dataVisualizer.select(item);

                svgObjectFactory.createAndAppendSvg(svgGroup, svgPredefined.getTreeNodeFullSettings().svg);

                // TECHNOTE:
                //      The 'svg:text' do not supported events like: 'mouseover' and 'mouseout'.
                //      So that, we needed to wrap 'svg:text' inside a 'svg:g' element in order to catch 'mouseover' and 'mouseout' events.
                var collapsibleContainer = svgGroup.select('g.collapsible-container'),
                    collapsibleController = svgGroup.select('text.collapsible-controller'),
                    ring = svgGroup.select('circle.ring');

                self._setCollapsibleState(/*senders*/[collapsibleController], /*target*/collapsibleController);

                self._setupHoverState(/*senders*/[collapsibleContainer], /*target*/collapsibleController);
                self._setupHoverState(/*senders*/[ring, collapsibleController], /*target*/ring);
                self._setupSelectedState(/*senders*/[ring], /*target*/ring);

                svgGroup.select('text.name')
                    .text(function (d) {
                        return d.name || d.Name;
                    });

                collapsibleController.on('click', $.hitch(self, self._click));
            });

            // Transition existing nodes to the parent's new position
            var nodeExit = node.exit().remove();

            // Update the links
            var link = this._svg.selectAll('.link')
                .data(links, function (d) {
                    return d.target.id;
                });

            // Enter any new links at the parent's previous position
            link.enter()
                .insert('line', 'g')
                .attr('class', 'link')
                .attr('x1', function (d) {
                    return d.source.y + 20;
                })
                .attr('y1', function (d) {
                    return d.source.x + 20;
                })
                .attr('x2', function (d) {
                    return d.target.y + 20;
                })
                .attr('y2', function (d) {
                    return d.target.x + 20;
                });

            // Transition existing links to the parent's new position
            link.exit().remove();
        },

        // =================================================================================================================================================
        // Tree node's functions
        // =================================================================================================================================================

        _click: function (d) {
            // summary:
            //      Toggle children on click.
            // tags:
            //      private

            // Ignore drag
            if (dataVisualizer.event && dataVisualizer.event.defaultPrevented) {
                return;
            }

            // Toggle children on click.
            if (d.children) {
                d._children = d.children;
                d.children = null;
            } else {
                d.children = d._children;
                d._children = null;
            }

            this._update();
        },

        _setupHoverState: function (senders, target) {
            // summary:
            //      Applies HOVER state for the given node
            // senders: [Array]
            //      The sender node that wanted to applies hover state
            // target: [Object]
            //      
            // tags:
            //      private

            $.each(senders, function (index, sender) {
                sender.on('mouseover', function (d) {
                    target.classed('hover', true);
                });

                sender.on('mouseout', function (d) {
                    target.classed('hover', false);
                });
            });
        },

        _setupSelectedState: function (senders, target) {
            // summary:
            //      Applies SELECTED state for the given node
            // senders: [Array]
            //      The sender node that wanted to applies selected state
            // target: [Object]
            //      
            // tags:
            //      private

            var self = this;
            $.each(senders, function (index, sender) {
                sender.on('click', function (d) {
                    self._clearSelectedState();
                    target.classed('selected', true);
                });
            });
        },

        _setCollapsibleState: function (senders, target) {
            // summary:
            //      Applies EXPANDED|COLLAPSED state for the given node
            // senders: [Array]
            //      The sender node that wanted to applies expanded state
            // target: [Object]
            //      
            // tags:
            //      private

            $.each(senders, function (index, sender) {
                sender.text(function (d) {
                    var expanded = d.children || d._children == null;
                    target.classed('expanded', expanded);

                    return expanded ? '-' : '+';
                });

                sender.style('display', function (d) {
                    var children = d.children || d._children,
                        display = children instanceof Array && children.length > 0;

                    return display ? '' : 'none';
                });
            });
        },

        _clearSelectedState: function () {
            // summary:
            //      Clear SELECTED state of the given target
            // tags:
            //      private

            this._svg.select('circle.ring.selected').classed('selected', false);
        }
    };

})(jQuery, window, document, d3, SvgObjectFactory, SvgPredefined);