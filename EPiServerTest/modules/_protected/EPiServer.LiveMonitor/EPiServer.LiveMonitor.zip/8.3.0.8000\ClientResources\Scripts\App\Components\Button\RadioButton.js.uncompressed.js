﻿define([
// libs
    'jquery',
// live monitor
    'components/ComponentFactory',
// resources
    'text!components/Button/Templates/RadioButton.html'
],

function (
// libs
    $,
// live monitor
    componentFactory,
// resources
    templateString
) {

    // =================================================================================================================================================
    // 'LiveMonitorRadioButton' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Button/LiveMonitorRadioButton'
    // summary:
    //      The jQuery plugin component for the radio button
    // description:
    //      use:
    //          $(target).LiveMonitorRadioButton(options);
    //      options:
    //          resources [Object]
    //          templateString [String]
    //          baseClasses [String]
    //          groupName [String]
    // tags:
    //      public

    // Create the defaults once
    var pluginName = 'LiveMonitorRadioButton',
        pluginOptions = {
            templateString: templateString,
            baseClasses: 'btn btn-sm btn-default livemonitor-radioButton',
            groupName: null
        },
        pluginDefinitions = {

            _postInit: function () {
                // summary:
                //      Post-initialize settings for the component
                // tags:
                //      protected, extension

                var buttonName = this._resources.buttonname,
                    groupName = this.options.groupName;

                buttonName && this._$wrapper.append(buttonName);

                var $button = this._$wrapper.find('.button-radio');
                groupName && $button.attr('name', groupName);
            }
        };

    // A really lightweight plugin wrapper around the constructor, 
    //  preventing against multiple instantiations
    $.fn[pluginName] = function (/*Object*/options) {
        // summary:
        //      Create a new jQuery plugin from the given settings
        // options: [Object]
        //      The given settings that wanted to decorates the default settings of the current component
        // returns: [Object]
        //      The jQuery plugin object
        // tags:
        //      protected

        // Decorates the default settings by the given settings
        $.extend(true, pluginOptions, options);

        // Create and then return a new jQuery plugin object
        return componentFactory.create(this, pluginName, pluginDefinitions, pluginOptions);
    };

});