﻿define([
// libs
    'jquery',
// live monitor
    'utility'
],

function (
// libs
    $,
// live monitor
    utility
) {

    // =================================================================================================================================================
    // 'CircleElementBuilder' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Svg/Factory/Builder/CircleElementBuilder'
    // summary:
    //      The element builder class for 'circle' SVG object
    // description:
    //      Create the 'CIRCLE' SVG element
    // tags:
    //      public

    var CircleElementBuilder = {

        elementName: 'circle',

        create: function (/*Object*/circleSettings, /*Array*/container, /*Function?*/recursiveCreate) {
            // summary:
            //      Create and then append a SVG circle without '<svg></svg>' tag
            // circleSettings: [Object]
            //      The given CIRCLE settings
            // container: [Array]
            //      The given container
            // recursiveCreate: [Function?]
            //      Indicated that should or should not create children recursively
            // tags:
            //      public

            if (!circleSettings) {
                return;
            }

            var circleList = container.selectAll(this.elementName)
                        .data(utility.getItemCollection(circleSettings))
                            .enter()
                    .append(this.elementName)
                        .attr('class', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.classes;
                        })
                        .attr('cx', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.cx;
                        })
                        .attr('cy', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.cy;
                        })
                        .attr('r', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.r;
                        })
                        .attr('fill', function (/*Object*/d) {
                            // d: [Object]
                            //      The given datum object

                            return d.fill;
                        });

            $.isFunction(recursiveCreate) && recursiveCreate(circleSettings, /*container*/circleList);
        }

    };

    return CircleElementBuilder;

});