﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'components/ComponentFactory',

    'components/Button/IconButton'
],

function (
// libs
    $,
// live monitor
    utility,

    componentFactory,

    iconButton
) {

    // =================================================================================================================================================
    // 'LiveMonitorAppSettingsButton' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Button/LiveMonitorAppSettingsButton'
    // summary:
    //      The jQuery plugin component for the application settings button
    // description:
    //      use:
    //          $(target).LiveMonitorAppSettingsButton(options);
    //      options:
    //          resources [Object]
    //          iconClasses [String]
    //          fullScreenSelector [String]
    // tags:
    //      public

    // Create the defaults once
    var pluginName = 'LiveMonitorAppSettingsButton',
        pluginOptions = {
            iconClasses: 'glyphicon-cog',
            fullScreenTarget: document.body,
            enableParam: 'isAppSettingsButtonVisible'
        },
        pluginDefinitions = {

            // =================================================================================================================================================
            // Overrided functions
            // =================================================================================================================================================

            _postInit: function () {
                // summary:
                //      Post-initialize settings for the component
                // tags:
                //      protected, extension

                this._setupLayout();
                this._setupEvents();
            },

            // =================================================================================================================================================
            // Private events
            // =================================================================================================================================================

            _onClick: function () {
                // summary:
                //      Fired when clicked on the current component
                // tags:
                //      private

                this.triggerContextEvent('showAppSettings');
            },

            // =================================================================================================================================================
            // Private functions
            // =================================================================================================================================================

            _setupLayout: function () {
                // summary:
                //      Setup layout for the current component
                // tags:
                //      private

                this._setTooltipText();

                var $iconButton = this._$wrapper.find('.button-icon'),
                    iconClasses = this.options.iconClasses;
                iconClasses && $iconButton && $iconButton.addClass(iconClasses);
            },

            _setupEvents: function () {
                // summary:
                //      Setup events for the current component
                // tags:
                //      private

                this._$wrapper.on('click', utility.hitch(this, this._onClick));
            },

            _setTooltipText: function () {
                // summary:
                //      Set tooltip text for the current component by the current fullscreen mode of the browser
                // tags:
                //      private

                this._$wrapper.attr('title', this.options.resources.tooltip);
            }
        };

    // A really lightweight plugin wrapper around the constructor, 
    //  preventing against multiple instantiations
    $.fn[pluginName] = function (/*Object*/options) {
        // summary:
        //      Create a new jQuery plugin from the given settings
        // options: [Object]
        //      The given settings that wanted to decorates the default settings of the current component
        // returns: [Object]
        //      The jQuery plugin object
        // tags:
        //      protected

        // Decorates the default settings by the given settings
        var baseOptions = $.fn['LiveMonitorIconButton'].prototype.pluginOptions,
            concreteOptions = $.extend(true, {}, baseOptions, pluginOptions, options);

        // Create and then return a new jQuery plugin object
        return componentFactory.create(this, pluginName, pluginDefinitions, concreteOptions);
    };

});