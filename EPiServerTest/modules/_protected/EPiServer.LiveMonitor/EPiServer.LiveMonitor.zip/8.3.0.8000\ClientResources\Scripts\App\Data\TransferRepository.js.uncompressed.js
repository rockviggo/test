﻿define([
// libs
    'jquery',
// live monitor
    'utility',

    'data/PersistenceCache'
],

function (
// libs
    $,
// live monitor
    utility,

    persistenceCache
) {

    // =================================================================================================================================================
    // 'TransferRepository' class information
    // =================================================================================================================================================
    // module:
    //      'App/Data/TransferRepository'
    // summary:
    //      The repository for application transfer data
    // description:
    //      Public functions:
    //          getData()
    //          saveData(/*Object*/updatedData, /*Object*/options)
    //          clearData()
    // tags:
    //      public

    var TransferRepository = {

        // _storageKey: [String] private
        //      The application svg templates key
        _storageKey: 'livemonitor-application-data',

        // _dataKey: [String]
        //      The transfer data key that used to get/set the transfer data from/to
        _dataKey: '',

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        getData: function () {
            // summary:
            //      Get the saved transfer data
            // returns: [Object]
            //      The saved transfer data
            // tags:
            //      public

            return this._storage.getData(this._dataKey);
        },

        saveData: function (/*Object*/updatedData, /*Object*/options) {
            // summary:
            //      Save the given updated transfer data
            // updatedData: [Object]
            //      The given updated transfer data object
            // options: [Object]
            //      Object's properties:
            //          replace: [Boolean]
            //              The flag that indicates should or should not replace the existing data
            //          dataKey: [String]
            //              The key of the data object
            //          fieldKey: [String]
            //              The key of the data object's field
            // tags:
            //      public

            if (!this._dataKey || !updatedData) {
                return;
            }

            options && (options.dataKey = this._dataKey);

            var data = {};
            data[this._dataKey] = updatedData;

            this._storage.saveData(data, options);
        },

        clearData: function () {
            // summary:
            //      Clear all the saved transfer data
            // tags:
            //      public

            if (!this._dataKey) {
                return;
            }

            this._storage.clear(this._dataKey);
        },

        // =================================================================================================================================================
        // Protected functions
        // =================================================================================================================================================

        _getLightOnlineVisitorList: function (/*Array*/onlineVisitorList) {
            // summary:
            //      Filter statistics data from the given collection
            // onlineVisitorList: [Array]
            //      The given collection of the online visitor object
            // returns: [Array]
            //      The collection of the online visitor object in lighter format
            // tags:
            //      protected

            if (!utility.isValidArray(onlineVisitorList)) {
                return;
            }

            var totalItems = onlineVisitorList.length,
                item,
                lightOnlineVisitorList = [];

            while (totalItems--) {
                item = onlineVisitorList[totalItems];
                if (!item) {
                    continue;
                }

                lightOnlineVisitorList.unshift([item.id, item.visit.currentContent.contentId, item.lastActivity].join('|'));
            }

            return lightOnlineVisitorList;
        }

    };

    var transferRepository = $.extend(true, {}, persistenceCache, TransferRepository);
    transferRepository.init();

    return transferRepository;

});