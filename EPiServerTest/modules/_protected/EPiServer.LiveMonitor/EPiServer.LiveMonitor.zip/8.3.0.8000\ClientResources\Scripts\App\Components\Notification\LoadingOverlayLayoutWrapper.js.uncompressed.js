﻿define([
// libs
    'jquery',
// live monitor
    'components/ComponentFactory',
// resources
    'text!components/Notification/Templates/LoadingOverlayLayoutWrapper.html'
],

function (
// libs
    $,
// live monitor
    componentFactory,
// resources
    templateString
) {

    // =================================================================================================================================================
    // 'LiveMonitorLoadingOverlayLayoutWrapper' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Notification/LiveMonitorLoadingOverlayLayoutWrapper'
    // summary:
    //      The jQuery plugin for loading overlay (SVG) layout wrapper component
    // description:
    //      use:
    //          $(target).LiveMonitorLoadingOverlayLayoutWrapper(options);
    //      options:
    //          resources: [Object]
    //          templateString [String]
    //          baseClasses [String]
    // tags:
    //      public

    // Create the defaults once
    var pluginName = 'LiveMonitorLoadingOverlayLayoutWrapper',
        pluginOptions = {
            templateString: templateString,
            baseClasses: 'livemonitor-loadingContainer'
        },
        pluginDefinitions = {

            // =================================================================================================================================================
            // Public functions
            // =================================================================================================================================================

            startLoading: function () {
                // summary:
                //      Start loading animation
                // tags:
                //      public

                this._$wrapper.addClass('livemonitor-loading');
            },

            stopLoading: function () {
                // summary:
                //      Stop loading animation
                // tags:
                //      public

                this._$wrapper.removeClass('livemonitor-loading');
            },

            // =================================================================================================================================================
            // Overrided functions
            // =================================================================================================================================================

            _preInit: function () {
                // summary:
                //      Pre-initialize settings for the component
                // tags:
                //      protected, extension

                var resources = this.options.resources,
                    templateString = this.options.templateString,
                    baseClasses = this.options.baseClasses;

                baseClasses && this._$wrapper.addClass(baseClasses);
                templateString && this._$wrapper.append(templateString);
            }
        };

    // A really lightweight plugin wrapper around the constructor, 
    //  preventing against multiple instantiations
    $.fn[pluginName] = function (/*Object*/options) {
        // summary:
        //      Create a new jQuery plugin from the given settings
        // options: [Object]
        //      The given settings that wanted to decorates the default settings of the current component
        // returns: [Object]
        //      The jQuery plugin object
        // tags:
        //      protected

        // Decorates the default settings by the given settings
        $.extend(true, pluginOptions, options);

        // Create and then return a new jQuery plugin object
        return componentFactory.create(this, pluginName, pluginDefinitions, pluginOptions);
    };

});