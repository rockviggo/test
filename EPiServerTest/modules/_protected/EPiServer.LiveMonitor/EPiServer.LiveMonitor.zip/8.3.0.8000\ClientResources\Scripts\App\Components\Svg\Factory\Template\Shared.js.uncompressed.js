﻿define([
// libs
    'jquery',
// live monitor
    'components/Svg/Factory/Template/BaseTemplate'
],

function (
// libs
    $,
// live monitor
    baseTemplate
) {

    // =================================================================================================================================================
    // 'SharedTemplate' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Svg/Factory/Template/SharedTemplate'
    // summary:
    //      Provides shared settings content markup template in SVG format
    // description:
    //      Public functions:
    //          load(/*String?*/text)
    //              Load SVG in JSON format
    //          loadExternal()
    //              Load SVG in raw format (SVG markup string)
    // tags:
    //      public

    var SharedTemplate = {

        // key: [String] public
        //      The unique key that used to register to the controller
        //      The controller used this key to identifies each registered template
        key: 'Shared',

        // name: [String] public
        //      The template name that used to register to the controller
        //      The application used this name to display
        name: 'Shared Template',

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        load: function () {
            // summary:
            //      Load the template
            // returns: [Object]
            //      The registered template in JSON format
            // tags:
            //      public

            return {
                svg: {
                    classes: 'livemonitor-svgSharedSettings',
                    defs: {
                        linearGradient: [
                            {
                                'elementId': 'livemonitor-verticalLinearGradient',
                                x1: '0%',
                                y1: '0%',
                                x2: '0%',
                                y2: '100%',
                                stop: [
                                    { offset: 0 },
                                    { offset: 0.5 },
                                    { offset: 1 }
                                ]
                            },
                            {
                                'elementId': 'livemonitor-verticalLinearGradient-selected',
                                x1: '0%',
                                y1: '0%',
                                x2: '0%',
                                y2: '100%',
                                stop: [
                                    { offset: 0 },
                                    { offset: 0.5 },
                                    { offset: 1 }
                                ]
                            },
                            {
                                'elementId': 'livemonitor-verticalLinearGradient-highway',
                                x1: '0%',
                                y1: '0%',
                                x2: '0%',
                                y2: '100%',
                                stop: [
                                    { offset: 0 },
                                    { offset: 0.5 },
                                    { offset: 1 }
                                ]
                            }
                        ],
                        marker: {
                            'elementId': 'livemonitor-highway-marker',
                            viewBox: '0 -5 10 10',
                            refX: 5,
                            refY: 0,
                            markerUnits: 'userSpaceOnUse',
                            markerWidth: 30,
                            markerHeight: 30,
                            orient: 'auto',
                            // The following commands are available for path data:
                            //  M = moveto
                            //  L = lineto
                            //  H = horizontal lineto
                            //  V = vertical lineto
                            //  C = curveto
                            //  S = smooth curveto
                            //  Q = quadratic Bézier curve
                            //  T = smooth quadratic Bézier curveto
                            //  A = elliptical Arc
                            //  Z = closepath
                            path: {
                                // The below defines a path that starts at position 0,-5
                                //  with a line to position 10,0
                                //  then from there, a line to 0,5
                                //  and finally closing the path back to 0,-5
                                d: 'M0 -5 L10 0 L0 5 Z'
                            }
                        }
                    }
                }
            };
        }

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

    };

    return $.extend(true, {}, baseTemplate, SharedTemplate);

});