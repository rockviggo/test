﻿define([
// libs
    'jquery',
    'd3',
// live monitor
    'utility'
],

function (
// libs
    $,
    dataVisualizer,
// live monitor
    utility
) {

    // =================================================================================================================================================
    // 'VibrateAnimation' class information
    // =================================================================================================================================================
    // module:
    //      'App/Components/Svg/Animation/Effect/VibrateAnimation'
    // summary:
    //      The vibrate effect
    // description:
    //      This is an animation for creating vibrate effect of visitor in Dashboard
    //      Public functions:
    //          apply(/*Object*/marker, /*Integer*/delay)
    // tags:
    //      public

    var VibrateAnimation = {

        // key: [String] public
        //      The unique key that used to register to the controller
        //      The controller used this key to identifies each registered animation maker
        key: 'Vibration',

        // name: [String] public
        //      The animation maker name that used to register to the controller
        //      The application used this name to display
        name: 'Vibration',

        // =================================================================================================================================================
        // Public functions
        // =================================================================================================================================================

        apply: function (/*Object*/marker, /*Integer*/delay) {
            // summary:
            //      Create an animation pattern
            // marker: [Object]
            //      The given object that wanted to bind the indicated animation
            // delay: [Integer]
            //      The given delay time
            // tags:
            //      public

            var repeat = utility.hitch(this, function () {
                this._vibrate(marker);
            });

            setTimeout(repeat, delay * 15);
        },

        // =================================================================================================================================================
        // Private functions
        // =================================================================================================================================================

        _vibrate: function (marker) {
            // summary:
            //      Create vibrate animation to the given marker
            // marker: [Object]
            //      The given marker object that wanted to be vibrated
            // tags:
            //      private

            return marker.transition()
                .attrTween('transform', utility.hitch(this, this._tweenTransform))
            ;
        },

        _tweenTransform: function (/*Object*/d) {
            // summary:
            //      Get X,Y position
            // d: [Object]
            //      The given object data
            // tags:
            //      private

            var back = false, x, y;

            return function (t) {
                // summary:
                //      Return X, Y and scale value at a time
                // t: [0,1]
                //      The time range

                if (back) {
                    x = d.x - 6 * (1 - t);
                    y = d.y - 2 * (1 - t);
                }
                else {
                    x = d.x + 6 * (1 - t);
                    y = d.y + 2 * (1 - t);
                }
                back = !back;

                return 'translate(' + x + ',' + y + ')';
            };
        }
    };

    return VibrateAnimation;

});