﻿define([
// Dojo
    "dojo/_base/declare",
    "dojo/_base/lang",

    "dojo/aspect",

// EPi Framework
    "epi/shell/widget/dialog/Dialog",

// CMS
    "epi-cms/widget/UrlContentSelector",
    "epi-cms/widget/ContentSelectorDialog",

// Resource
    "epi/i18n!epi-cms/nls/socialreach.outreach"
],

function (
// Dojo
    declare,
    lang,
    aspect,

// Framework
    Dialog,

//CMS
    UrlContentSelector,
    ContentSelectorDialog,

// Resource
    res

    ) {

    // summary:
    //      Inherite from epi-cms/widget/UrlContentSelector,
    //      overide _getDialog method to inject model.
    return declare([UrlContentSelector], {

        _getDialog: function () {
            // Verifies that the dialog instance and its dom node existings or not
            if (this.dialog && this.dialog.domNode) {
                return this.dialog;
            }

            this.contentSelectorDialog = new ContentSelectorDialog({
                canSelectOwnerContent: this.canSelectOwnerContent,
                showButtons: false,
                roots: this.roots,
                allowedTypes: this.allowedTypes,
                /*Patch here*/
                model: this.model,
                "_typesToDisplay": this.typesToDisplay
            });

            var context = this.contentSelectorDialog;
            aspect.before(this.contentSelectorDialog, "_onTreeNodeClick", lang.hitch(this, function (content) {
                if (this.isAllowedType && this.isAllowedType(content)) {
                    this.allowedTypes.push(content.typeIdentifier);
                }
            }));

            var title = res.selectmedia;
            this.dialog = new Dialog({
                title: title,
                dialogClass: "epi-dialog-portrait",
                content: this.contentSelectorDialog,
                destroyOnHide: true
            });

            this.connect(this.contentSelectorDialog, "onChange", "_setDialogButtonState");
            this.connect(this.dialog, 'onExecute', '_onDialogExecute');
            this.connect(this.dialog, 'onHide', '_onDialogHide');

            return this.dialog;
        }
    });
});